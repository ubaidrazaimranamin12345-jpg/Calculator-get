# CalcPro - Modern Calculator Platform

## Overview

CalcPro is a comprehensive calculator web application similar to Calculator.net, built with modern technologies and contemporary design. The project provides multiple calculator types including basic arithmetic, financial calculators (mortgage, loan), health calculators (BMI, calorie), mathematical tools (scientific, percentage), and utility calculators (age, date). The application features a modern, responsive interface with calculation history storage and a modular architecture for different calculator types.

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Updates (Latest)

### August 2025 - Complete Application Build
- ✓ Built comprehensive calculator platform with all major calculator types
- ✓ Implemented modern UI/UX with responsive design and contemporary styling
- ✓ Added search functionality and category-based navigation
- ✓ Created calculation history system with persistent storage
- ✓ Established full-stack architecture with proper error handling
- ✓ Fixed all TypeScript compilation issues and dependencies
- ✓ Successfully deployed and running on Replit platform
- ✓ Created comprehensive documentation (README.md, FEATURES.md, DEPLOYMENT.md)

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript using Vite as the build tool
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack React Query for server state management
- **Form Handling**: React Hook Form with Zod validation via @hookform/resolvers

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Design**: RESTful API with routes for CRUD operations on calculations
- **Development Server**: Custom Vite integration for hot module replacement in development
- **Error Handling**: Centralized error handling middleware with structured error responses

### Data Layer
- **Database**: PostgreSQL configured for production use
- **ORM**: Drizzle ORM with type-safe queries and migrations
- **Database Provider**: Neon serverless PostgreSQL (@neondatabase/serverless)
- **Development Storage**: In-memory storage implementation for development/testing
- **Schema**: Single calculations table storing type, expression, result, inputs (JSONB), and timestamps

### Component Architecture
- **Calculator Types**: Modular calculator components (Basic, Scientific, Financial, Health, Tools)
- **Shared Components**: Reusable UI components (SearchBar, CalculatorGrid, various form inputs)
- **Layout System**: Responsive grid layouts with mobile-first design approach
- **Icon System**: Emoji-based icon mapping for calculator categories

### Development Tooling
- **Build System**: Vite with React plugin and TypeScript support
- **Database Management**: Drizzle Kit for schema migrations and database operations
- **Code Quality**: TypeScript strict mode with comprehensive type checking
- **Development Experience**: Hot reload, error overlays, and Replit integration plugins

## External Dependencies

### Core Framework Dependencies
- **React Ecosystem**: React 18, React DOM, React Hook Form, TanStack React Query
- **UI Framework**: Radix UI component primitives, Tailwind CSS, class-variance-authority
- **Build Tools**: Vite, TypeScript, esbuild for production builds

### Database and Backend
- **Database**: Neon serverless PostgreSQL, Drizzle ORM, connect-pg-simple for session storage
- **Server**: Express.js with middleware for JSON parsing, CORS handling, and error management
- **Validation**: Zod for runtime type validation and schema generation

### Mathematical and Utility Libraries
- **Mathematics**: Math.js for expression evaluation and scientific calculations
- **Date Handling**: date-fns for date calculations and formatting
- **Utilities**: nanoid for unique ID generation, clsx for conditional styling

### Development and Quality Tools
- **Replit Integration**: Custom plugins for development environment integration
- **Component Library**: shadcn/ui with extensive pre-built components
- **Styling Utilities**: PostCSS with Autoprefixer, Tailwind CSS configuration