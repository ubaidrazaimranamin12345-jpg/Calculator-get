# CalcPro Deployment Guide

## Deployment Options

### 🚀 Replit Deployment (Recommended)
The easiest way to deploy your CalcPro application.

#### Steps:
1. **Prepare for Deployment**
   - Ensure all features are working in development
   - Verify no console errors or warnings
   - Test all calculator functions

2. **Deploy on Replit**
   - Click the "Deploy" button in your Replit workspace
   - Choose "Autoscale Deployment" for automatic scaling
   - Configure custom domain if needed
   - Set environment variables if using external services

3. **Environment Variables**
   ```bash
   # For production database (optional)
   DATABASE_URL=your_postgresql_url
   
   # Node environment
   NODE_ENV=production
   ```

#### Benefits:
- Automatic HTTPS/TLS certificates
- Built-in health checks
- Automatic scaling
- Easy rollback options
- Custom domain support
- Zero configuration needed

### 🌐 Alternative Deployment Options

#### Vercel Deployment
1. **Setup**
   ```bash
   npm install -g vercel
   vercel
   ```

2. **Configuration** (vercel.json)
   ```json
   {
     "version": 2,
     "builds": [
       {
         "src": "server/index.ts",
         "use": "@vercel/node"
       },
       {
         "src": "client/index.html",
         "use": "@vercel/static-build",
         "config": {
           "distDir": "client/dist"
         }
       }
     ],
     "routes": [
       {
         "src": "/api/(.*)",
         "dest": "server/index.ts"
       },
       {
         "src": "/(.*)",
         "dest": "client/dist/$1"
       }
     ]
   }
   ```

#### Netlify Deployment
1. **Build Settings**
   - Build command: `npm run build`
   - Publish directory: `client/dist`
   - Functions directory: `server/`

2. **Redirects** (_redirects file)
   ```
   /api/* /.netlify/functions/index 200
   /* /index.html 200
   ```

#### Railway Deployment
1. **Setup**
   ```bash
   # Install Railway CLI
   npm install -g @railway/cli
   
   # Login and deploy
   railway login
   railway init
   railway up
   ```

2. **Configuration**
   - Add start script in package.json
   - Configure environment variables
   - Set up PostgreSQL addon if needed

## Database Setup

### 🐘 PostgreSQL Production Setup

#### Option 1: Neon (Recommended)
1. Create account at [neon.tech](https://neon.tech)
2. Create new project
3. Copy connection string
4. Add to environment variables:
   ```bash
   DATABASE_URL=postgresql://username:password@host/database?sslmode=require
   ```

#### Option 2: Supabase
1. Create account at [supabase.com](https://supabase.com)
2. Create new project
3. Go to Settings > Database
4. Copy connection string
5. Add to environment variables

#### Option 3: PlanetScale
1. Create account at [planetscale.com](https://planetscale.com)
2. Create database
3. Create branch (main)
4. Get connection string
5. Configure environment

### 📝 Database Migration
When using production database:

1. **Generate Migration**
   ```bash
   npx drizzle-kit generate:pg
   ```

2. **Run Migration**
   ```bash
   npx drizzle-kit push:pg
   ```

3. **Verify Tables**
   Check that `calculations` table is created with correct schema.

## Environment Configuration

### 📋 Environment Variables

#### Development (.env)
```bash
NODE_ENV=development
PORT=5000
```

#### Production
```bash
NODE_ENV=production
PORT=5000
DATABASE_URL=your_production_database_url
VITE_API_URL=https://your-domain.com
```

### 🔧 Build Configuration

#### Package.json Scripts
```json
{
  "scripts": {
    "dev": "NODE_ENV=development tsx server/index.ts",
    "build": "npm run build:client && npm run build:server",
    "build:client": "cd client && vite build",
    "build:server": "tsc server/index.ts --outDir dist",
    "start": "node dist/index.js",
    "preview": "vite preview"
  }
}
```

## Performance Optimization

### 🚀 Build Optimizations

#### Vite Configuration (vite.config.ts)
```typescript
export default defineConfig({
  build: {
    rollupOptions: {
      output: {
        manualChunks: {
          vendor: ['react', 'react-dom'],
          ui: ['@radix-ui/react-button', '@radix-ui/react-card'],
          math: ['mathjs']
        }
      }
    },
    chunkSizeWarningLimit: 1000
  },
  optimizeDeps: {
    include: ['mathjs', 'date-fns']
  }
});
```

#### Client-side Optimizations
- Code splitting for calculator components
- Lazy loading of heavy math libraries
- Image optimization for icons
- CSS minification
- Bundle size monitoring

### 📊 Monitoring Setup

#### Production Monitoring
1. **Error Tracking**
   - Sentry integration
   - Error boundary implementation
   - API error logging

2. **Performance Monitoring**
   - Web Vitals tracking
   - Bundle size monitoring
   - API response time tracking

3. **User Analytics**
   - Calculator usage statistics
   - User flow analysis
   - Feature adoption tracking

## Security Configuration

### 🔒 Security Headers
```typescript
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('X-XSS-Protection', '1; mode=block');
  res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  next();
});
```

### 🛡️ Input Validation
- Zod schema validation on all inputs
- SQL injection prevention with Drizzle ORM
- XSS protection with proper sanitization
- Rate limiting for API endpoints

## Testing Before Deployment

### ✅ Pre-deployment Checklist

#### Functionality Tests
- [ ] All calculators work correctly
- [ ] Search function returns relevant results
- [ ] Navigation works on all pages
- [ ] Mobile responsive design
- [ ] Error handling works properly
- [ ] Calculation history saves and loads

#### Performance Tests
- [ ] Page load times < 3 seconds
- [ ] Smooth animations and transitions
- [ ] No memory leaks in calculations
- [ ] Bundle size optimized

#### Browser Compatibility
- [ ] Chrome (latest 2 versions)
- [ ] Firefox (latest 2 versions)  
- [ ] Safari (latest 2 versions)
- [ ] Edge (latest 2 versions)
- [ ] Mobile browsers

#### Security Tests
- [ ] Input validation working
- [ ] No sensitive data in client code
- [ ] HTTPS enforcement
- [ ] Security headers implemented

## Post-Deployment

### 📈 Monitoring & Maintenance
1. **Set up monitoring dashboards**
2. **Configure alerts for errors**
3. **Regular dependency updates**
4. **Performance monitoring**
5. **User feedback collection**

### 🔄 Update Process
1. **Test changes in development**
2. **Run automated tests**
3. **Deploy to staging (if available)**
4. **Deploy to production**
5. **Monitor for issues**
6. **Rollback if necessary**

This deployment guide ensures your CalcPro application runs smoothly in production with optimal performance and security.