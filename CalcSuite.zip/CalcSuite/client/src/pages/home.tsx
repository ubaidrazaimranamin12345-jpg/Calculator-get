import { useState } from 'react';
import { Link } from 'wouter';
import { Calculator, Search, DollarSign, Heart, SquareRadical, Wrench } from 'lucide-react';
import BasicCalculator from '@/components/basic-calculator';
import SearchBar from '@/components/search-bar';
import CalculatorGrid from '@/components/calculator-grid';

const calculatorCategories = [
  {
    id: 'financial',
    title: 'Financial Calculators',
    description: 'Tools for loans, mortgages, investments, and financial planning',
    icon: DollarSign,
    color: 'financial',
    calculators: [
      { type: 'mortgage', title: 'Mortgage Calculator', description: 'Calculate monthly payments and total interest', icon: 'home' },
      { type: 'loan', title: 'Loan Calculator', description: 'Personal and business loan calculations', icon: 'hand-holding-usd' },
      { type: 'investment', title: 'Investment Calculator', description: 'ROI and compound interest calculations', icon: 'chart-line' },
      { type: 'retirement', title: 'Retirement Calculator', description: 'Plan your retirement savings', icon: 'piggy-bank' },
      { type: 'tax', title: 'Tax Calculator', description: 'Income tax and deduction calculations', icon: 'receipt' },
      { type: 'compound', title: 'Compound Interest', description: 'Calculate compound growth over time', icon: 'percentage' },
      { type: 'auto-loan', title: 'Auto Loan', description: 'Vehicle financing calculations', icon: 'car' },
      { type: 'salary', title: 'Salary Calculator', description: 'Convert between salary formats', icon: 'money-check-alt' },
    ],
  },
  {
    id: 'health',
    title: 'Health & Fitness Calculators',
    description: 'Track your health metrics and fitness goals',
    icon: Heart,
    color: 'health',
    calculators: [
      { type: 'bmi', title: 'BMI Calculator', description: 'Body Mass Index calculator', icon: 'weight' },
      { type: 'calorie', title: 'Calorie Calculator', description: 'Daily caloric needs calculator', icon: 'fire' },
      { type: 'bmr', title: 'BMR Calculator', description: 'Basal Metabolic Rate calculator', icon: 'tachometer-alt' },
      { type: 'body-fat', title: 'Body Fat Calculator', description: 'Estimate body fat percentage', icon: 'user' },
      { type: 'ideal-weight', title: 'Ideal Weight', description: 'Calculate your ideal weight range', icon: 'balance-scale' },
      { type: 'pace', title: 'Pace Calculator', description: 'Running and walking pace calculator', icon: 'running' },
    ],
  },
  {
    id: 'math',
    title: 'Math Calculators',
    description: 'Advanced mathematical calculations and tools',
    icon: SquareRadical,
    color: 'math',
    calculators: [
      { type: 'scientific', title: 'Scientific Calculator', description: 'Advanced mathematical functions', icon: 'calculator' },
      { type: 'fraction', title: 'Fraction Calculator', description: 'Calculate with fractions', icon: 'divide' },
      { type: 'percentage', title: 'Percentage Calculator', description: 'Percentage calculations made easy', icon: 'percent' },
      { type: 'triangle', title: 'Triangle Calculator', description: 'Triangle properties and measurements', icon: 'play' },
      { type: 'random', title: 'Random Number', description: 'Generate random numbers', icon: 'dice' },
      { type: 'standard-deviation', title: 'Standard Deviation', description: 'Statistical calculations', icon: 'chart-bar' },
    ],
  },
  {
    id: 'tools',
    title: 'Other Calculators & Tools',
    description: 'Utility calculators for everyday use',
    icon: Wrench,
    color: 'tools',
    calculators: [
      { type: 'age', title: 'Age Calculator', description: 'Calculate exact age in years, months, days', icon: 'calendar-alt' },
      { type: 'date', title: 'Date Calculator', description: 'Add or subtract days from dates', icon: 'calendar' },
      { type: 'time', title: 'Time Calculator', description: 'Time duration calculations', icon: 'clock' },
      { type: 'gpa', title: 'GPA Calculator', description: 'Grade point average calculator', icon: 'graduation-cap' },
      { type: 'password', title: 'Password Generator', description: 'Generate secure passwords', icon: 'key' },
      { type: 'conversion', title: 'Unit Converter', description: 'Convert between different units', icon: 'exchange-alt' },
      { type: 'subnet', title: 'Subnet Calculator', description: 'IP subnet calculations', icon: 'network-wired' },
      { type: 'concrete', title: 'Concrete Calculator', description: 'Construction material calculations', icon: 'hammer' },
    ],
  },
];

export default function Home() {
  const [searchQuery, setSearchQuery] = useState('');

  const filteredCategories = calculatorCategories.map(category => ({
    ...category,
    calculators: category.calculators.filter(calc =>
      calc.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      calc.description.toLowerCase().includes(searchQuery.toLowerCase())
    ),
  })).filter(category => category.calculators.length > 0);

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-primary to-accent rounded-xl flex items-center justify-center">
                <Calculator className="text-white" size={20} />
              </div>
              <h1 className="text-2xl font-bold text-slate-900">CalcPro</h1>
            </div>
            
            <nav className="hidden md:flex space-x-8">
              <a href="#calculators" className="text-slate-600 hover:text-primary font-medium transition-colors">Calculators</a>
              <a href="#financial" className="text-slate-600 hover:text-primary font-medium transition-colors">Financial</a>
              <a href="#health" className="text-slate-600 hover:text-primary font-medium transition-colors">Health</a>
              <a href="#math" className="text-slate-600 hover:text-primary font-medium transition-colors">Math</a>
              <a href="#tools" className="text-slate-600 hover:text-primary font-medium transition-colors">Tools</a>
            </nav>
            
            <button className="md:hidden text-slate-600 hover:text-slate-900" data-testid="button-mobile-menu">
              <i className="fas fa-bars text-xl"></i>
            </button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="gradient-bg py-16 lg:py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl lg:text-5xl font-bold text-white mb-4">
              Free Online Calculators
            </h2>
            <p className="text-xl text-blue-100 max-w-2xl mx-auto">
              Professional-grade calculators for finance, health, math, and everyday calculations
            </p>
          </div>
          
          {/* Search Bar */}
          <div className="max-w-2xl mx-auto mb-12">
            <SearchBar
              value={searchQuery}
              onChange={setSearchQuery}
              placeholder="Search for a calculator..."
            />
          </div>
          
          {/* Featured Calculator */}
          <div className="max-w-md mx-auto">
            <BasicCalculator />
          </div>
        </div>
      </section>

      {/* Calculator Categories */}
      <section className="py-16 lg:py-20" id="calculators">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {filteredCategories.map((category) => (
            <div key={category.id} className="mb-16" id={category.id}>
              <div className="flex items-center mb-8">
                <div className={`w-12 h-12 bg-${category.color}-bg rounded-xl flex items-center justify-center mr-4`}>
                  <category.icon className={`text-${category.color} text-xl`} size={24} />
                </div>
                <div>
                  <h3 className="text-3xl font-bold text-slate-900">{category.title}</h3>
                  <p className="text-slate-600 mt-1">{category.description}</p>
                </div>
              </div>
              
              <CalculatorGrid calculators={category.calculators} categoryColor={category.color} />
            </div>
          ))}
          
          {filteredCategories.length === 0 && searchQuery && (
            <div className="text-center py-16">
              <Search className="mx-auto h-12 w-12 text-slate-400 mb-4" />
              <h3 className="text-lg font-semibold text-slate-900 mb-2">No calculators found</h3>
              <p className="text-slate-600">Try adjusting your search query</p>
            </div>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-8 h-8 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center">
                  <Calculator className="text-white text-sm" size={16} />
                </div>
                <h3 className="text-xl font-bold">CalcPro</h3>
              </div>
              <p className="text-slate-400 mb-4">Professional-grade calculators for all your calculation needs.</p>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Financial</h4>
              <ul className="space-y-2 text-slate-400">
                <li><Link href="/calculator/mortgage" className="hover:text-white transition-colors">Mortgage Calculator</Link></li>
                <li><Link href="/calculator/loan" className="hover:text-white transition-colors">Loan Calculator</Link></li>
                <li><Link href="/calculator/investment" className="hover:text-white transition-colors">Investment Calculator</Link></li>
                <li><Link href="/calculator/tax" className="hover:text-white transition-colors">Tax Calculator</Link></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Health & Math</h4>
              <ul className="space-y-2 text-slate-400">
                <li><Link href="/calculator/bmi" className="hover:text-white transition-colors">BMI Calculator</Link></li>
                <li><Link href="/calculator/calorie" className="hover:text-white transition-colors">Calorie Calculator</Link></li>
                <li><Link href="/calculator/scientific" className="hover:text-white transition-colors">Scientific Calculator</Link></li>
                <li><Link href="/calculator/percentage" className="hover:text-white transition-colors">Percentage Calculator</Link></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Tools</h4>
              <ul className="space-y-2 text-slate-400">
                <li><Link href="/calculator/age" className="hover:text-white transition-colors">Age Calculator</Link></li>
                <li><Link href="/calculator/date" className="hover:text-white transition-colors">Date Calculator</Link></li>
                <li><Link href="/calculator/conversion" className="hover:text-white transition-colors">Unit Converter</Link></li>
                <li><Link href="/calculator/password" className="hover:text-white transition-colors">Password Generator</Link></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-slate-800 mt-12 pt-8 text-center text-slate-400">
            <p>&copy; 2024 CalcPro. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
