import { useParams, Link } from 'wouter';
import { ArrowLeft, Calculator as CalcIcon, Home } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

// Import calculator components
import MortgageCalculator from '@/components/financial/mortgage-calculator';
import LoanCalculator from '@/components/financial/loan-calculator';
import BMICalculator from '@/components/health/bmi-calculator';
import CalorieCalculator from '@/components/health/calorie-calculator';
import PercentageCalculator from '@/components/math/percentage-calculator';
import ScientificCalculator from '@/components/math/scientific-calculator';
import AgeCalculator from '@/components/tools/age-calculator';
import DateCalculator from '@/components/tools/date-calculator';

const calculatorComponents: { [key: string]: React.ComponentType } = {
  mortgage: MortgageCalculator,
  loan: LoanCalculator,
  bmi: BMICalculator,
  calorie: CalorieCalculator,
  percentage: PercentageCalculator,
  scientific: ScientificCalculator,
  age: AgeCalculator,
  date: DateCalculator,
};

const calculatorTitles: { [key: string]: string } = {
  mortgage: 'Mortgage Calculator',
  loan: 'Loan Calculator',
  bmi: 'BMI Calculator',
  calorie: 'Calorie Calculator',
  percentage: 'Percentage Calculator',
  scientific: 'Scientific Calculator',
  age: 'Age Calculator',
  date: 'Date Calculator',
};

export default function Calculator() {
  const params = useParams();
  const type = params.type as string;
  
  const CalculatorComponent = calculatorComponents[type];
  const title = calculatorTitles[type];

  if (!CalculatorComponent) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <Card className="w-full max-w-md mx-4">
          <CardContent className="pt-6 text-center">
            <CalcIcon className="h-12 w-12 text-slate-400 mx-auto mb-4" />
            <h1 className="text-2xl font-bold text-slate-900 mb-2">Calculator Not Found</h1>
            <p className="text-slate-600 mb-4">
              The calculator you're looking for doesn't exist or is not yet implemented.
            </p>
            <Link href="/">
              <Button data-testid="button-home">
                <Home className="mr-2 h-4 w-4" />
                Back to Home
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <Link href="/">
                <Button variant="ghost" size="sm" data-testid="button-back">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back
                </Button>
              </Link>
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-gradient-to-br from-primary to-accent rounded-xl flex items-center justify-center">
                  <CalcIcon className="text-white" size={20} />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-slate-900">CalcPro</h1>
                  <p className="text-sm text-slate-600">{title}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Calculator Content */}
      <main className="py-8">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl font-bold text-center">{title}</CardTitle>
            </CardHeader>
            <CardContent>
              <CalculatorComponent />
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
