import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { MathCalculator } from '@/lib/calculations';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

export default function PercentageCalculator() {
  // What is X% of Y
  const [percentOf_percent, setPercentOf_percent] = useState('');
  const [percentOf_value, setPercentOf_value] = useState('');
  const [percentOf_result, setPercentOf_result] = useState<number | null>(null);

  // X is what % of Y
  const [whatPercent_value, setWhatPercent_value] = useState('');
  const [whatPercent_total, setWhatPercent_total] = useState('');
  const [whatPercent_result, setWhatPercent_result] = useState<number | null>(null);

  // Percentage increase/decrease
  const [change_original, setChange_original] = useState('');
  const [change_new, setChange_new] = useState('');
  const [change_result, setChange_result] = useState<{ increase?: number; decrease?: number } | null>(null);

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const saveCalculationMutation = useMutation({
    mutationFn: async (data: { type: string; expression: string; result: string; inputs: any }) => {
      return await apiRequest('POST', '/api/calculations', data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/calculations'] });
    },
  });

  const calculatePercentOf = () => {
    const p = parseFloat(percentOf_percent);
    const v = parseFloat(percentOf_value);

    if (isNaN(p) || isNaN(v)) {
      toast({
        title: "Invalid Input",
        description: "Please enter valid numbers",
        variant: "destructive",
      });
      return;
    }

    const result = MathCalculator.calculatePercentage(v, p);
    setPercentOf_result(result);

    // Save to history
    const expression = `What is ${p}% of ${v}?`;
    const resultText = `${result}`;
    
    saveCalculationMutation.mutate({
      type: 'percentage',
      expression,
      result: resultText,
      inputs: { type: 'percentOf', percent: p, value: v },
    });
  };

  const calculateWhatPercent = () => {
    const value = parseFloat(whatPercent_value);
    const total = parseFloat(whatPercent_total);

    if (isNaN(value) || isNaN(total) || total === 0) {
      toast({
        title: "Invalid Input",
        description: "Please enter valid numbers (total cannot be zero)",
        variant: "destructive",
      });
      return;
    }

    const result = (value / total) * 100;
    setWhatPercent_result(result);

    // Save to history
    const expression = `${value} is what % of ${total}?`;
    const resultText = `${result.toFixed(2)}%`;
    
    saveCalculationMutation.mutate({
      type: 'percentage',
      expression,
      result: resultText,
      inputs: { type: 'whatPercent', value, total },
    });
  };

  const calculatePercentageChange = () => {
    const original = parseFloat(change_original);
    const newValue = parseFloat(change_new);

    if (isNaN(original) || isNaN(newValue) || original === 0) {
      toast({
        title: "Invalid Input",
        description: "Please enter valid numbers (original value cannot be zero)",
        variant: "destructive",
      });
      return;
    }

    let result: { increase?: number; decrease?: number } = {};
    
    if (newValue > original) {
      result.increase = MathCalculator.percentageIncrease(original, newValue);
    } else {
      result.decrease = MathCalculator.percentageDecrease(original, newValue);
    }
    
    setChange_result(result);

    // Save to history
    const expression = `Percentage change from ${original} to ${newValue}`;
    const changeType = newValue > original ? 'increase' : 'decrease';
    const changeValue = newValue > original ? result.increase : result.decrease;
    const resultText = `${changeValue?.toFixed(2)}% ${changeType}`;
    
    saveCalculationMutation.mutate({
      type: 'percentage',
      expression,
      result: resultText,
      inputs: { type: 'change', original, newValue },
    });
  };

  const resetAll = () => {
    setPercentOf_percent('');
    setPercentOf_value('');
    setPercentOf_result(null);
    setWhatPercent_value('');
    setWhatPercent_total('');
    setWhatPercent_result(null);
    setChange_original('');
    setChange_new('');
    setChange_result(null);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <Tabs defaultValue="percent-of" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="percent-of">What is X% of Y?</TabsTrigger>
          <TabsTrigger value="what-percent">X is what % of Y?</TabsTrigger>
          <TabsTrigger value="percent-change">% Change</TabsTrigger>
        </TabsList>

        <TabsContent value="percent-of" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Calculate Percentage of a Number</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="percent">Percentage (%)</Label>
                  <Input
                    id="percent"
                    type="number"
                    step="0.01"
                    value={percentOf_percent}
                    onChange={(e) => setPercentOf_percent(e.target.value)}
                    placeholder="e.g., 15"
                    data-testid="input-percent"
                  />
                </div>
                <div>
                  <Label htmlFor="value">Of Value</Label>
                  <Input
                    id="value"
                    type="number"
                    step="0.01"
                    value={percentOf_value}
                    onChange={(e) => setPercentOf_value(e.target.value)}
                    placeholder="e.g., 200"
                    data-testid="input-value"
                  />
                </div>
              </div>
              <Button onClick={calculatePercentOf} data-testid="button-calculate-percent-of">
                Calculate
              </Button>
              {percentOf_result !== null && (
                <div className="p-4 bg-primary/10 rounded-lg">
                  <div className="text-sm text-slate-600">Result</div>
                  <div className="text-2xl font-bold text-primary" data-testid="text-percent-of-result">
                    {percentOf_result}
                  </div>
                  <div className="text-sm text-slate-600 mt-1">
                    {percentOf_percent}% of {percentOf_value} is {percentOf_result}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="what-percent" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Find What Percentage One Number is of Another</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="whatPercent_value">Value</Label>
                  <Input
                    id="whatPercent_value"
                    type="number"
                    step="0.01"
                    value={whatPercent_value}
                    onChange={(e) => setWhatPercent_value(e.target.value)}
                    placeholder="e.g., 25"
                    data-testid="input-what-percent-value"
                  />
                </div>
                <div>
                  <Label htmlFor="whatPercent_total">Total</Label>
                  <Input
                    id="whatPercent_total"
                    type="number"
                    step="0.01"
                    value={whatPercent_total}
                    onChange={(e) => setWhatPercent_total(e.target.value)}
                    placeholder="e.g., 100"
                    data-testid="input-what-percent-total"
                  />
                </div>
              </div>
              <Button onClick={calculateWhatPercent} data-testid="button-calculate-what-percent">
                Calculate
              </Button>
              {whatPercent_result !== null && (
                <div className="p-4 bg-primary/10 rounded-lg">
                  <div className="text-sm text-slate-600">Result</div>
                  <div className="text-2xl font-bold text-primary" data-testid="text-what-percent-result">
                    {whatPercent_result.toFixed(2)}%
                  </div>
                  <div className="text-sm text-slate-600 mt-1">
                    {whatPercent_value} is {whatPercent_result.toFixed(2)}% of {whatPercent_total}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="percent-change" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Calculate Percentage Increase or Decrease</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="original">Original Value</Label>
                  <Input
                    id="original"
                    type="number"
                    step="0.01"
                    value={change_original}
                    onChange={(e) => setChange_original(e.target.value)}
                    placeholder="e.g., 50"
                    data-testid="input-original"
                  />
                </div>
                <div>
                  <Label htmlFor="newValue">New Value</Label>
                  <Input
                    id="newValue"
                    type="number"
                    step="0.01"
                    value={change_new}
                    onChange={(e) => setChange_new(e.target.value)}
                    placeholder="e.g., 65"
                    data-testid="input-new"
                  />
                </div>
              </div>
              <Button onClick={calculatePercentageChange} data-testid="button-calculate-change">
                Calculate
              </Button>
              {change_result && (
                <div className="p-4 bg-primary/10 rounded-lg">
                  <div className="text-sm text-slate-600">Result</div>
                  <div className="text-2xl font-bold text-primary" data-testid="text-change-result">
                    {change_result.increase ? 
                      `+${change_result.increase.toFixed(2)}%` : 
                      `-${change_result.decrease?.toFixed(2)}%`
                    }
                  </div>
                  <div className="text-sm text-slate-600 mt-1">
                    {change_result.increase ? 
                      `Percentage increase from ${change_original} to ${change_new}` :
                      `Percentage decrease from ${change_original} to ${change_new}`
                    }
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="flex justify-center">
        <Button onClick={resetAll} variant="outline" data-testid="button-reset-all">
          Reset All
        </Button>
      </div>
    </div>
  );
}
