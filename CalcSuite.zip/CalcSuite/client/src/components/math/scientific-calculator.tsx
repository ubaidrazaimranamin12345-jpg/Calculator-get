import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Calculator } from '@/lib/calculations';
import { evaluate } from 'mathjs';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

export default function ScientificCalculator() {
  const [display, setDisplay] = useState('0');
  const [expression, setExpression] = useState('');
  const [isNewNumber, setIsNewNumber] = useState(true);
  const [angleMode, setAngleMode] = useState<'deg' | 'rad'>('deg');
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const saveCalculationMutation = useMutation({
    mutationFn: async (data: { type: string; expression: string; result: string }) => {
      return await apiRequest('POST', '/api/calculations', data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/calculations'] });
    },
  });

  const handleNumber = (num: string) => {
    if (isNewNumber) {
      setDisplay(num);
      setIsNewNumber(false);
    } else {
      setDisplay(display === '0' ? num : display + num);
    }
  };

  const handleOperator = (op: string) => {
    const newExpression = expression + display + ' ' + op + ' ';
    setExpression(newExpression);
    setIsNewNumber(true);
  };

  const handleFunction = (func: string) => {
    try {
      let result: number;
      const value = parseFloat(display);
      
      switch (func) {
        case 'sin':
          result = angleMode === 'deg' ? Math.sin((value * Math.PI) / 180) : Math.sin(value);
          break;
        case 'cos':
          result = angleMode === 'deg' ? Math.cos((value * Math.PI) / 180) : Math.cos(value);
          break;
        case 'tan':
          result = angleMode === 'deg' ? Math.tan((value * Math.PI) / 180) : Math.tan(value);
          break;
        case 'asin':
          result = angleMode === 'deg' ? (Math.asin(value) * 180) / Math.PI : Math.asin(value);
          break;
        case 'acos':
          result = angleMode === 'deg' ? (Math.acos(value) * 180) / Math.PI : Math.acos(value);
          break;
        case 'atan':
          result = angleMode === 'deg' ? (Math.atan(value) * 180) / Math.PI : Math.atan(value);
          break;
        case 'ln':
          result = Math.log(value);
          break;
        case 'log':
          result = Math.log10(value);
          break;
        case 'sqrt':
          result = Math.sqrt(value);
          break;
        case 'square':
          result = value * value;
          break;
        case 'cube':
          result = value * value * value;
          break;
        case 'exp':
          result = Math.exp(value);
          break;
        case '10x':
          result = Math.pow(10, value);
          break;
        case 'factorial':
          result = factorial(value);
          break;
        case 'reciprocal':
          result = 1 / value;
          break;
        default:
          throw new Error('Unknown function');
      }

      if (!isFinite(result)) {
        throw new Error('Math error');
      }

      setDisplay(Calculator.formatResult(result));
      setIsNewNumber(true);
    } catch (error) {
      setDisplay('Error');
      setIsNewNumber(true);
      toast({
        title: "Math Error",
        description: `Cannot calculate ${func}(${display})`,
        variant: "destructive",
      });
    }
  };

  const factorial = (n: number): number => {
    if (n < 0 || !Number.isInteger(n)) throw new Error('Invalid input for factorial');
    if (n === 0 || n === 1) return 1;
    if (n > 170) throw new Error('Number too large for factorial');
    let result = 1;
    for (let i = 2; i <= n; i++) {
      result *= i;
    }
    return result;
  };

  const handleConstants = (constant: string) => {
    switch (constant) {
      case 'pi':
        setDisplay(Math.PI.toString());
        break;
      case 'e':
        setDisplay(Math.E.toString());
        break;
    }
    setIsNewNumber(true);
  };

  const handleEquals = () => {
    try {
      const fullExpression = expression + display;
      const result = Calculator.evaluate(fullExpression);
      setDisplay(result);
      setExpression('');
      setIsNewNumber(true);

      // Save to history
      saveCalculationMutation.mutate({
        type: 'scientific',
        expression: fullExpression,
        result: result,
      });
    } catch (error) {
      setDisplay('Error');
      setIsNewNumber(true);
      toast({
        title: "Error",
        description: "Invalid expression",
        variant: "destructive",
      });
    }
  };

  const handleClear = () => {
    setDisplay('0');
    setExpression('');
    setIsNewNumber(true);
  };

  const handleDecimal = () => {
    if (isNewNumber) {
      setDisplay('0.');
      setIsNewNumber(false);
    } else if (!display.includes('.')) {
      setDisplay(display + '.');
    }
  };

  const handleBackspace = () => {
    if (display.length > 1) {
      setDisplay(display.slice(0, -1));
    } else {
      setDisplay('0');
      setIsNewNumber(true);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-4">
      <Card className="calculator-container shadow-2xl">
        <CardContent className="p-6">
          <div className="calculator-display rounded-2xl p-6 mb-6 text-right">
            <div className="text-slate-400 text-sm mb-2" data-testid="text-expression">
              {expression || ' '}
            </div>
            <div className="text-white text-3xl font-mono" data-testid="text-display">
              {display}
            </div>
            <div className="text-right mt-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setAngleMode(angleMode === 'deg' ? 'rad' : 'deg')}
                className="text-slate-400 hover:text-white"
                data-testid="button-angle-mode"
              >
                {angleMode.toUpperCase()}
              </Button>
            </div>
          </div>
          
          <div className="grid grid-cols-8 gap-2">
            {/* Row 1: Functions */}
            <Button className="calculator-button bg-slate-200 hover:bg-slate-300 text-slate-700 text-sm py-2" onClick={() => handleFunction('sin')} data-testid="button-sin">sin</Button>
            <Button className="calculator-button bg-slate-200 hover:bg-slate-300 text-slate-700 text-sm py-2" onClick={() => handleFunction('cos')} data-testid="button-cos">cos</Button>
            <Button className="calculator-button bg-slate-200 hover:bg-slate-300 text-slate-700 text-sm py-2" onClick={() => handleFunction('tan')} data-testid="button-tan">tan</Button>
            <Button className="calculator-button bg-slate-200 hover:bg-slate-300 text-slate-700 text-sm py-2" onClick={() => handleFunction('asin')} data-testid="button-asin">sin⁻¹</Button>
            <Button className="calculator-button bg-slate-200 hover:bg-slate-300 text-slate-700 text-sm py-2" onClick={() => handleFunction('acos')} data-testid="button-acos">cos⁻¹</Button>
            <Button className="calculator-button bg-slate-200 hover:bg-slate-300 text-slate-700 text-sm py-2" onClick={() => handleFunction('atan')} data-testid="button-atan">tan⁻¹</Button>
            <Button className="calculator-button bg-slate-100 hover:bg-slate-200 text-slate-700 py-2" onClick={handleBackspace} data-testid="button-backspace">⌫</Button>
            <Button className="calculator-button bg-slate-100 hover:bg-slate-200 text-slate-700 py-2" onClick={handleClear} data-testid="button-clear">C</Button>

            {/* Row 2: More functions */}
            <Button className="calculator-button bg-slate-200 hover:bg-slate-300 text-slate-700 text-sm py-2" onClick={() => handleFunction('ln')} data-testid="button-ln">ln</Button>
            <Button className="calculator-button bg-slate-200 hover:bg-slate-300 text-slate-700 text-sm py-2" onClick={() => handleFunction('log')} data-testid="button-log">log</Button>
            <Button className="calculator-button bg-slate-200 hover:bg-slate-300 text-slate-700 text-sm py-2" onClick={() => handleFunction('exp')} data-testid="button-exp">eˣ</Button>
            <Button className="calculator-button bg-slate-200 hover:bg-slate-300 text-slate-700 text-sm py-2" onClick={() => handleFunction('10x')} data-testid="button-10x">10ˣ</Button>
            <Button className="calculator-button bg-slate-200 hover:bg-slate-300 text-slate-700 text-sm py-2" onClick={() => handleFunction('square')} data-testid="button-square">x²</Button>
            <Button className="calculator-button bg-slate-200 hover:bg-slate-300 text-slate-700 text-sm py-2" onClick={() => handleFunction('cube')} data-testid="button-cube">x³</Button>
            <Button className="calculator-button bg-slate-200 hover:bg-slate-300 text-slate-700 text-sm py-2" onClick={() => handleFunction('sqrt')} data-testid="button-sqrt">√</Button>
            <Button className="calculator-button bg-primary hover:bg-primary/90 text-white py-2" onClick={() => handleOperator('/')} data-testid="button-divide">÷</Button>

            {/* Row 3: Constants and numbers */}
            <Button className="calculator-button bg-slate-200 hover:bg-slate-300 text-slate-700 text-sm py-2" onClick={() => handleConstants('pi')} data-testid="button-pi">π</Button>
            <Button className="calculator-button bg-slate-200 hover:bg-slate-300 text-slate-700 text-sm py-2" onClick={() => handleConstants('e')} data-testid="button-e">e</Button>
            <Button className="calculator-button bg-slate-200 hover:bg-slate-300 text-slate-700 text-sm py-2" onClick={() => handleFunction('factorial')} data-testid="button-factorial">x!</Button>
            <Button className="calculator-button bg-slate-200 hover:bg-slate-300 text-slate-700 text-sm py-2" onClick={() => handleFunction('reciprocal')} data-testid="button-reciprocal">1/x</Button>
            <Button className="calculator-button bg-white hover:bg-slate-50 text-slate-900 py-2" onClick={() => handleNumber('7')} data-testid="button-7">7</Button>
            <Button className="calculator-button bg-white hover:bg-slate-50 text-slate-900 py-2" onClick={() => handleNumber('8')} data-testid="button-8">8</Button>
            <Button className="calculator-button bg-white hover:bg-slate-50 text-slate-900 py-2" onClick={() => handleNumber('9')} data-testid="button-9">9</Button>
            <Button className="calculator-button bg-primary hover:bg-primary/90 text-white py-2" onClick={() => handleOperator('*')} data-testid="button-multiply">×</Button>

            {/* Row 4: Numbers */}
            <Button className="calculator-button bg-slate-200 hover:bg-slate-300 text-slate-700 text-sm py-2" onClick={() => handleOperator('^')} data-testid="button-power">xʸ</Button>
            <Button className="calculator-button bg-slate-200 hover:bg-slate-300 text-slate-700 text-sm py-2" onClick={() => handleOperator('(')} data-testid="button-open-paren">(</Button>
            <Button className="calculator-button bg-slate-200 hover:bg-slate-300 text-slate-700 text-sm py-2" onClick={() => handleOperator(')')} data-testid="button-close-paren">)</Button>
            <Button className="calculator-button bg-slate-200 hover:bg-slate-300 text-slate-700 text-sm py-2" onClick={() => handleOperator('%')} data-testid="button-percent">%</Button>
            <Button className="calculator-button bg-white hover:bg-slate-50 text-slate-900 py-2" onClick={() => handleNumber('4')} data-testid="button-4">4</Button>
            <Button className="calculator-button bg-white hover:bg-slate-50 text-slate-900 py-2" onClick={() => handleNumber('5')} data-testid="button-5">5</Button>
            <Button className="calculator-button bg-white hover:bg-slate-50 text-slate-900 py-2" onClick={() => handleNumber('6')} data-testid="button-6">6</Button>
            <Button className="calculator-button bg-primary hover:bg-primary/90 text-white py-2" onClick={() => handleOperator('-')} data-testid="button-subtract">-</Button>

            {/* Row 5: Numbers */}
            <div className="col-span-4"></div>
            <Button className="calculator-button bg-white hover:bg-slate-50 text-slate-900 py-2" onClick={() => handleNumber('1')} data-testid="button-1">1</Button>
            <Button className="calculator-button bg-white hover:bg-slate-50 text-slate-900 py-2" onClick={() => handleNumber('2')} data-testid="button-2">2</Button>
            <Button className="calculator-button bg-white hover:bg-slate-50 text-slate-900 py-2" onClick={() => handleNumber('3')} data-testid="button-3">3</Button>
            <Button className="calculator-button bg-primary hover:bg-primary/90 text-white py-2" onClick={() => handleOperator('+')} data-testid="button-add">+</Button>

            {/* Row 6: Zero and equals */}
            <div className="col-span-4"></div>
            <Button className="calculator-button bg-white hover:bg-slate-50 text-slate-900 py-2 col-span-2" onClick={() => handleNumber('0')} data-testid="button-0">0</Button>
            <Button className="calculator-button bg-white hover:bg-slate-50 text-slate-900 py-2" onClick={handleDecimal} data-testid="button-decimal">.</Button>
            <Button className="calculator-button bg-accent hover:bg-accent/90 text-white py-2" onClick={handleEquals} data-testid="button-equals">=</Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
