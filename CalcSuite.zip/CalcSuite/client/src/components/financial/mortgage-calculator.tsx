import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { FinancialCalculator } from '@/lib/calculations';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

export default function MortgageCalculator() {
  const [principal, setPrincipal] = useState('');
  const [rate, setRate] = useState('');
  const [years, setYears] = useState('');
  const [result, setResult] = useState<{ monthlyPayment: number; totalPayment: number; totalInterest: number } | null>(null);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const saveCalculationMutation = useMutation({
    mutationFn: async (data: { type: string; expression: string; result: string; inputs: any }) => {
      return await apiRequest('POST', '/api/calculations', data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/calculations'] });
    },
  });

  const handleCalculate = () => {
    const p = parseFloat(principal);
    const r = parseFloat(rate);
    const y = parseFloat(years);

    if (isNaN(p) || isNaN(r) || isNaN(y) || p <= 0 || r < 0 || y <= 0) {
      toast({
        title: "Invalid Input",
        description: "Please enter valid positive numbers",
        variant: "destructive",
      });
      return;
    }

    const calculation = FinancialCalculator.calculateMortgage(p, r, y);
    setResult(calculation);

    // Save to history
    const expression = `Mortgage: $${p} at ${r}% for ${y} years`;
    const resultText = `Monthly: $${calculation.monthlyPayment}`;
    
    saveCalculationMutation.mutate({
      type: 'mortgage',
      expression,
      result: resultText,
      inputs: { principal: p, rate: r, years: y },
    });
  };

  const handleReset = () => {
    setPrincipal('');
    setRate('');
    setYears('');
    setResult(null);
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Loan Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="principal">Loan Amount ($)</Label>
              <Input
                id="principal"
                type="number"
                value={principal}
                onChange={(e) => setPrincipal(e.target.value)}
                placeholder="e.g., 300000"
                data-testid="input-principal"
              />
            </div>
            <div>
              <Label htmlFor="rate">Interest Rate (%)</Label>
              <Input
                id="rate"
                type="number"
                step="0.01"
                value={rate}
                onChange={(e) => setRate(e.target.value)}
                placeholder="e.g., 4.5"
                data-testid="input-rate"
              />
            </div>
            <div>
              <Label htmlFor="years">Loan Term (years)</Label>
              <Input
                id="years"
                type="number"
                value={years}
                onChange={(e) => setYears(e.target.value)}
                placeholder="e.g., 30"
                data-testid="input-years"
              />
            </div>
            <div className="flex space-x-2">
              <Button onClick={handleCalculate} className="flex-1" data-testid="button-calculate">
                Calculate
              </Button>
              <Button onClick={handleReset} variant="outline" data-testid="button-reset">
                Reset
              </Button>
            </div>
          </CardContent>
        </Card>

        {result && (
          <Card>
            <CardHeader>
              <CardTitle>Payment Breakdown</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-4 bg-primary/10 rounded-lg">
                <div className="text-sm text-slate-600">Monthly Payment</div>
                <div className="text-2xl font-bold text-primary" data-testid="text-monthly-payment">
                  ${result.monthlyPayment.toLocaleString()}
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-600">Total Payment:</span>
                  <span className="font-semibold" data-testid="text-total-payment">
                    ${result.totalPayment.toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">Total Interest:</span>
                  <span className="font-semibold" data-testid="text-total-interest">
                    ${result.totalInterest.toLocaleString()}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {result && (
        <Card>
          <CardHeader>
            <CardTitle>Calculation Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-sm text-slate-600">
              <p>
                For a loan amount of <strong>${parseFloat(principal).toLocaleString()}</strong> at{' '}
                <strong>{rate}%</strong> interest rate over <strong>{years} years</strong>:
              </p>
              <ul className="mt-2 space-y-1 list-disc list-inside">
                <li>You'll pay <strong>${result.monthlyPayment}</strong> per month</li>
                <li>Total amount paid will be <strong>${result.totalPayment.toLocaleString()}</strong></li>
                <li>Total interest paid will be <strong>${result.totalInterest.toLocaleString()}</strong></li>
              </ul>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
