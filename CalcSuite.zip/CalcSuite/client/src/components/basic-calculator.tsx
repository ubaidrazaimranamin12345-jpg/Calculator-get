import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Calculator } from '@/lib/calculations';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

export default function BasicCalculator() {
  const [display, setDisplay] = useState('0');
  const [expression, setExpression] = useState('');
  const [isNewNumber, setIsNewNumber] = useState(true);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const saveCalculationMutation = useMutation({
    mutationFn: async (data: { type: string; expression: string; result: string }) => {
      return await apiRequest('POST', '/api/calculations', data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/calculations'] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save calculation",
        variant: "destructive",
      });
    },
  });

  const handleNumber = (num: string) => {
    if (isNewNumber) {
      setDisplay(num);
      setIsNewNumber(false);
    } else {
      setDisplay(display === '0' ? num : display + num);
    }
  };

  const handleOperator = (op: string) => {
    const newExpression = expression + display + ' ' + op + ' ';
    setExpression(newExpression);
    setIsNewNumber(true);
  };

  const handleEquals = () => {
    try {
      const fullExpression = expression + display;
      const result = Calculator.evaluate(fullExpression);
      setDisplay(result);
      setExpression('');
      setIsNewNumber(true);

      // Save to history
      saveCalculationMutation.mutate({
        type: 'basic',
        expression: fullExpression,
        result: result,
      });
    } catch (error) {
      setDisplay('Error');
      setIsNewNumber(true);
      toast({
        title: "Error",
        description: "Invalid expression",
        variant: "destructive",
      });
    }
  };

  const handleClear = () => {
    setDisplay('0');
    setExpression('');
    setIsNewNumber(true);
  };

  const handleDecimal = () => {
    if (isNewNumber) {
      setDisplay('0.');
      setIsNewNumber(false);
    } else if (!display.includes('.')) {
      setDisplay(display + '.');
    }
  };

  const handleToggleSign = () => {
    if (display !== '0') {
      setDisplay(display.startsWith('-') ? display.slice(1) : '-' + display);
    }
  };

  const handlePercentage = () => {
    const value = parseFloat(display);
    setDisplay((value / 100).toString());
  };

  return (
    <Card className="calculator-container shadow-2xl">
      <CardContent className="p-6">
        <div className="calculator-display rounded-2xl p-6 mb-6 text-right">
          <div className="text-slate-400 text-sm mb-2" data-testid="text-expression">
            {expression || ' '}
          </div>
          <div className="text-white text-4xl font-mono" data-testid="text-display">
            {display}
          </div>
        </div>
        
        <div className="grid grid-cols-4 gap-3">
          {/* Row 1: Functions */}
          <Button
            className="calculator-button bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold py-4 rounded-xl"
            onClick={handleClear}
            data-testid="button-clear"
          >
            AC
          </Button>
          <Button
            className="calculator-button bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold py-4 rounded-xl"
            onClick={handleToggleSign}
            data-testid="button-sign"
          >
            ±
          </Button>
          <Button
            className="calculator-button bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold py-4 rounded-xl"
            onClick={handlePercentage}
            data-testid="button-percent"
          >
            %
          </Button>
          <Button
            className="calculator-button bg-primary hover:bg-primary/90 text-white font-semibold py-4 rounded-xl"
            onClick={() => handleOperator('÷')}
            data-testid="button-divide"
          >
            ÷
          </Button>
          
          {/* Row 2: Numbers */}
          <Button
            className="calculator-button bg-white hover:bg-slate-50 text-slate-900 font-semibold py-4 rounded-xl border border-slate-200"
            onClick={() => handleNumber('7')}
            data-testid="button-7"
          >
            7
          </Button>
          <Button
            className="calculator-button bg-white hover:bg-slate-50 text-slate-900 font-semibold py-4 rounded-xl border border-slate-200"
            onClick={() => handleNumber('8')}
            data-testid="button-8"
          >
            8
          </Button>
          <Button
            className="calculator-button bg-white hover:bg-slate-50 text-slate-900 font-semibold py-4 rounded-xl border border-slate-200"
            onClick={() => handleNumber('9')}
            data-testid="button-9"
          >
            9
          </Button>
          <Button
            className="calculator-button bg-primary hover:bg-primary/90 text-white font-semibold py-4 rounded-xl"
            onClick={() => handleOperator('×')}
            data-testid="button-multiply"
          >
            ×
          </Button>
          
          {/* Row 3: Numbers */}
          <Button
            className="calculator-button bg-white hover:bg-slate-50 text-slate-900 font-semibold py-4 rounded-xl border border-slate-200"
            onClick={() => handleNumber('4')}
            data-testid="button-4"
          >
            4
          </Button>
          <Button
            className="calculator-button bg-white hover:bg-slate-50 text-slate-900 font-semibold py-4 rounded-xl border border-slate-200"
            onClick={() => handleNumber('5')}
            data-testid="button-5"
          >
            5
          </Button>
          <Button
            className="calculator-button bg-white hover:bg-slate-50 text-slate-900 font-semibold py-4 rounded-xl border border-slate-200"
            onClick={() => handleNumber('6')}
            data-testid="button-6"
          >
            6
          </Button>
          <Button
            className="calculator-button bg-primary hover:bg-primary/90 text-white font-semibold py-4 rounded-xl"
            onClick={() => handleOperator('-')}
            data-testid="button-subtract"
          >
            -
          </Button>
          
          {/* Row 4: Numbers */}
          <Button
            className="calculator-button bg-white hover:bg-slate-50 text-slate-900 font-semibold py-4 rounded-xl border border-slate-200"
            onClick={() => handleNumber('1')}
            data-testid="button-1"
          >
            1
          </Button>
          <Button
            className="calculator-button bg-white hover:bg-slate-50 text-slate-900 font-semibold py-4 rounded-xl border border-slate-200"
            onClick={() => handleNumber('2')}
            data-testid="button-2"
          >
            2
          </Button>
          <Button
            className="calculator-button bg-white hover:bg-slate-50 text-slate-900 font-semibold py-4 rounded-xl border border-slate-200"
            onClick={() => handleNumber('3')}
            data-testid="button-3"
          >
            3
          </Button>
          <Button
            className="calculator-button bg-primary hover:bg-primary/90 text-white font-semibold py-4 rounded-xl"
            onClick={() => handleOperator('+')}
            data-testid="button-add"
          >
            +
          </Button>
          
          {/* Row 5: Zero and Equals */}
          <Button
            className="calculator-button bg-white hover:bg-slate-50 text-slate-900 font-semibold py-4 rounded-xl border border-slate-200 col-span-2"
            onClick={() => handleNumber('0')}
            data-testid="button-0"
          >
            0
          </Button>
          <Button
            className="calculator-button bg-white hover:bg-slate-50 text-slate-900 font-semibold py-4 rounded-xl border border-slate-200"
            onClick={handleDecimal}
            data-testid="button-decimal"
          >
            .
          </Button>
          <Button
            className="calculator-button bg-accent hover:bg-accent/90 text-white font-semibold py-4 rounded-xl"
            onClick={handleEquals}
            data-testid="button-equals"
          >
            =
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
