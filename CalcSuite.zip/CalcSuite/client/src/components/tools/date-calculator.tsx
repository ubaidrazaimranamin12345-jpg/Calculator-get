import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { UtilityCalculator } from '@/lib/calculations';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

export default function DateCalculator() {
  // Add/Subtract days
  const [startDate, setStartDate] = useState(new Date().toISOString().split('T')[0]);
  const [daysToAdd, setDaysToAdd] = useState('');
  const [operation, setOperation] = useState<'add' | 'subtract'>('add');
  const [addSubtractResult, setAddSubtractResult] = useState<string | null>(null);

  // Date difference
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');
  const [differenceResult, setDifferenceResult] = useState<{
    totalDays: number;
    years: number;
    months: number;
    days: number;
  } | null>(null);

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const saveCalculationMutation = useMutation({
    mutationFn: async (data: { type: string; expression: string; result: string; inputs: any }) => {
      return await apiRequest('POST', '/api/calculations', data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/calculations'] });
    },
  });

  const handleAddSubtractDays = () => {
    if (!startDate || !daysToAdd) {
      toast({
        title: "Invalid Input",
        description: "Please enter both date and number of days",
        variant: "destructive",
      });
      return;
    }

    const days = parseInt(daysToAdd);
    if (isNaN(days)) {
      toast({
        title: "Invalid Input",
        description: "Please enter a valid number of days",
        variant: "destructive",
      });
      return;
    }

    const date = new Date(startDate);
    let resultDate: Date;

    if (operation === 'add') {
      resultDate = UtilityCalculator.addDaysToDate(date, days);
    } else {
      resultDate = UtilityCalculator.subtractDaysFromDate(date, days);
    }

    const resultString = resultDate.toISOString().split('T')[0];
    setAddSubtractResult(resultString);

    // Save to history
    const expression = `${operation === 'add' ? 'Add' : 'Subtract'} ${days} days ${operation === 'add' ? 'to' : 'from'} ${startDate}`;
    const resultText = resultString;
    
    saveCalculationMutation.mutate({
      type: 'date',
      expression,
      result: resultText,
      inputs: { startDate, days, operation },
    });
  };

  const handleDateDifference = () => {
    if (!fromDate || !toDate) {
      toast({
        title: "Invalid Input",
        description: "Please enter both dates",
        variant: "destructive",
      });
      return;
    }

    const from = new Date(fromDate);
    const to = new Date(toDate);

    // Calculate total days difference
    const timeDiff = to.getTime() - from.getTime();
    const totalDays = Math.floor(timeDiff / (1000 * 3600 * 24));

    // Calculate years, months, days difference
    let years = to.getFullYear() - from.getFullYear();
    let months = to.getMonth() - from.getMonth();
    let days = to.getDate() - from.getDate();

    if (days < 0) {
      months--;
      const lastMonth = new Date(to.getFullYear(), to.getMonth(), 0);
      days += lastMonth.getDate();
    }

    if (months < 0) {
      years--;
      months += 12;
    }

    setDifferenceResult({
      totalDays: Math.abs(totalDays),
      years: Math.abs(years),
      months: Math.abs(months),
      days: Math.abs(days),
    });

    // Save to history
    const expression = `Difference between ${fromDate} and ${toDate}`;
    const resultText = `${Math.abs(totalDays)} days (${Math.abs(years)}y ${Math.abs(months)}m ${Math.abs(days)}d)`;
    
    saveCalculationMutation.mutate({
      type: 'date',
      expression,
      result: resultText,
      inputs: { fromDate, toDate, type: 'difference' },
    });
  };

  const handleUseToday = (setter: (date: string) => void) => {
    setter(new Date().toISOString().split('T')[0]);
  };

  const resetAddSubtract = () => {
    setStartDate(new Date().toISOString().split('T')[0]);
    setDaysToAdd('');
    setOperation('add');
    setAddSubtractResult(null);
  };

  const resetDifference = () => {
    setFromDate('');
    setToDate('');
    setDifferenceResult(null);
  };

  const formatDate = (dateString: string): string => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <Tabs defaultValue="add-subtract" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="add-subtract">Add/Subtract Days</TabsTrigger>
          <TabsTrigger value="difference">Date Difference</TabsTrigger>
        </TabsList>

        <TabsContent value="add-subtract" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Add or Subtract Days</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="operation">Operation</Label>
                  <Select value={operation} onValueChange={(value) => setOperation(value as 'add' | 'subtract')}>
                    <SelectTrigger data-testid="select-operation">
                      <SelectValue placeholder="Select operation" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="add">Add days</SelectItem>
                      <SelectItem value="subtract">Subtract days</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="startDate">Starting Date</Label>
                  <div className="flex space-x-2">
                    <Input
                      id="startDate"
                      type="date"
                      value={startDate}
                      onChange={(e) => setStartDate(e.target.value)}
                      className="flex-1"
                      data-testid="input-start-date"
                    />
                    <Button 
                      onClick={() => handleUseToday(setStartDate)} 
                      variant="outline" 
                      size="sm"
                      data-testid="button-use-today-start"
                    >
                      Today
                    </Button>
                  </div>
                </div>
                <div>
                  <Label htmlFor="daysToAdd">Number of Days</Label>
                  <Input
                    id="daysToAdd"
                    type="number"
                    value={daysToAdd}
                    onChange={(e) => setDaysToAdd(e.target.value)}
                    placeholder="e.g., 30"
                    data-testid="input-days"
                  />
                </div>
                <div className="flex space-x-2">
                  <Button onClick={handleAddSubtractDays} className="flex-1" data-testid="button-calculate-add-subtract">
                    Calculate
                  </Button>
                  <Button onClick={resetAddSubtract} variant="outline" data-testid="button-reset-add-subtract">
                    Reset
                  </Button>
                </div>
              </CardContent>
            </Card>

            {addSubtractResult && (
              <Card>
                <CardHeader>
                  <CardTitle>Result Date</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-6 bg-primary/10 rounded-lg text-center">
                    <div className="text-2xl font-bold text-primary mb-2" data-testid="text-result-date">
                      {addSubtractResult}
                    </div>
                    <div className="text-sm text-slate-600">
                      {formatDate(addSubtractResult)}
                    </div>
                  </div>
                  <div className="text-sm text-slate-600">
                    <strong>{operation === 'add' ? 'Adding' : 'Subtracting'}</strong> {daysToAdd} days{' '}
                    <strong>{operation === 'add' ? 'to' : 'from'}</strong> {startDate} gives you {addSubtractResult}.
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>

        <TabsContent value="difference" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Calculate Date Difference</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="fromDate">From Date</Label>
                  <div className="flex space-x-2">
                    <Input
                      id="fromDate"
                      type="date"
                      value={fromDate}
                      onChange={(e) => setFromDate(e.target.value)}
                      className="flex-1"
                      data-testid="input-from-date"
                    />
                    <Button 
                      onClick={() => handleUseToday(setFromDate)} 
                      variant="outline" 
                      size="sm"
                      data-testid="button-use-today-from"
                    >
                      Today
                    </Button>
                  </div>
                </div>
                <div>
                  <Label htmlFor="toDate">To Date</Label>
                  <div className="flex space-x-2">
                    <Input
                      id="toDate"
                      type="date"
                      value={toDate}
                      onChange={(e) => setToDate(e.target.value)}
                      className="flex-1"
                      data-testid="input-to-date"
                    />
                    <Button 
                      onClick={() => handleUseToday(setToDate)} 
                      variant="outline" 
                      size="sm"
                      data-testid="button-use-today-to"
                    >
                      Today
                    </Button>
                  </div>
                </div>
                <div className="flex space-x-2">
                  <Button onClick={handleDateDifference} className="flex-1" data-testid="button-calculate-difference">
                    Calculate Difference
                  </Button>
                  <Button onClick={resetDifference} variant="outline" data-testid="button-reset-difference">
                    Reset
                  </Button>
                </div>
              </CardContent>
            </Card>

            {differenceResult && (
              <Card>
                <CardHeader>
                  <CardTitle>Date Difference</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-6 bg-primary/10 rounded-lg text-center">
                    <div className="text-2xl font-bold text-primary mb-2" data-testid="text-difference-result">
                      {differenceResult.totalDays} days
                    </div>
                    <div className="text-sm text-slate-600">
                      {differenceResult.years} years, {differenceResult.months} months, {differenceResult.days} days
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between items-center p-3 bg-slate-50 rounded-lg">
                      <span className="text-slate-600">Total Hours:</span>
                      <span className="font-semibold" data-testid="text-total-hours-diff">
                        {(differenceResult.totalDays * 24).toLocaleString()}
                      </span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-slate-50 rounded-lg">
                      <span className="text-slate-600">Total Minutes:</span>
                      <span className="font-semibold" data-testid="text-total-minutes-diff">
                        {(differenceResult.totalDays * 24 * 60).toLocaleString()}
                      </span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-slate-50 rounded-lg">
                      <span className="text-slate-600">Total Weeks:</span>
                      <span className="font-semibold" data-testid="text-total-weeks-diff">
                        {Math.floor(differenceResult.totalDays / 7)}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {differenceResult && (
            <Card>
              <CardHeader>
                <CardTitle>Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-sm text-slate-600">
                  The difference between <strong>{fromDate}</strong> and <strong>{toDate}</strong> is{' '}
                  <strong>{differenceResult.totalDays} days</strong>, which equals{' '}
                  <strong>{differenceResult.years} years</strong>,{' '}
                  <strong>{differenceResult.months} months</strong>, and{' '}
                  <strong>{differenceResult.days} days</strong>.
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
