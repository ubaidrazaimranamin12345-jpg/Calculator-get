import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { UtilityCalculator } from '@/lib/calculations';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

export default function AgeCalculator() {
  const [birthDate, setBirthDate] = useState('');
  const [targetDate, setTargetDate] = useState(new Date().toISOString().split('T')[0]);
  const [result, setResult] = useState<{ years: number; months: number; days: number; totalDays: number } | null>(null);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const saveCalculationMutation = useMutation({
    mutationFn: async (data: { type: string; expression: string; result: string; inputs: any }) => {
      return await apiRequest('POST', '/api/calculations', data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/calculations'] });
    },
  });

  const calculateTotalDays = (birthDate: Date, targetDate: Date): number => {
    const timeDiff = targetDate.getTime() - birthDate.getTime();
    return Math.floor(timeDiff / (1000 * 3600 * 24));
  };

  const handleCalculate = () => {
    if (!birthDate) {
      toast({
        title: "Invalid Input",
        description: "Please enter your birth date",
        variant: "destructive",
      });
      return;
    }

    const birth = new Date(birthDate);
    const target = new Date(targetDate);

    if (birth > target) {
      toast({
        title: "Invalid Input",
        description: "Birth date cannot be after the target date",
        variant: "destructive",
      });
      return;
    }

    if (birth.getTime() === target.getTime()) {
      toast({
        title: "Invalid Input",
        description: "Birth date and target date cannot be the same",
        variant: "destructive",
      });
      return;
    }

    const ageCalculation = UtilityCalculator.calculateAge(birth);
    const totalDays = calculateTotalDays(birth, target);
    
    // If target date is not today, recalculate for target date
    let finalResult = ageCalculation;
    if (target.toDateString() !== new Date().toDateString()) {
      const today = new Date();
      let years = target.getFullYear() - birth.getFullYear();
      let months = target.getMonth() - birth.getMonth();
      let days = target.getDate() - birth.getDate();
      
      if (days < 0) {
        months--;
        const lastMonth = new Date(target.getFullYear(), target.getMonth(), 0);
        days += lastMonth.getDate();
      }
      
      if (months < 0) {
        years--;
        months += 12;
      }
      
      finalResult = { years, months, days };
    }

    setResult({ ...finalResult, totalDays });

    // Save to history
    const expression = `Age from ${birthDate} to ${targetDate}`;
    const resultText = `${finalResult.years}y ${finalResult.months}m ${finalResult.days}d (${totalDays} total days)`;
    
    saveCalculationMutation.mutate({
      type: 'age',
      expression,
      result: resultText,
      inputs: { birthDate, targetDate },
    });
  };

  const handleReset = () => {
    setBirthDate('');
    setTargetDate(new Date().toISOString().split('T')[0]);
    setResult(null);
  };

  const handleUseToday = () => {
    setTargetDate(new Date().toISOString().split('T')[0]);
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Calculate Age</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="birthDate">Birth Date</Label>
              <Input
                id="birthDate"
                type="date"
                value={birthDate}
                onChange={(e) => setBirthDate(e.target.value)}
                data-testid="input-birth-date"
              />
            </div>
            <div>
              <Label htmlFor="targetDate">Calculate age as of (Target Date)</Label>
              <div className="flex space-x-2">
                <Input
                  id="targetDate"
                  type="date"
                  value={targetDate}
                  onChange={(e) => setTargetDate(e.target.value)}
                  className="flex-1"
                  data-testid="input-target-date"
                />
                <Button 
                  onClick={handleUseToday} 
                  variant="outline" 
                  size="sm"
                  data-testid="button-use-today"
                >
                  Today
                </Button>
              </div>
            </div>
            <div className="flex space-x-2">
              <Button onClick={handleCalculate} className="flex-1" data-testid="button-calculate">
                Calculate Age
              </Button>
              <Button onClick={handleReset} variant="outline" data-testid="button-reset">
                Reset
              </Button>
            </div>
          </CardContent>
        </Card>

        {result && (
          <Card>
            <CardHeader>
              <CardTitle>Your Age</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-6 bg-primary/10 rounded-lg text-center">
                <div className="text-3xl font-bold text-primary mb-2" data-testid="text-age-result">
                  {result.years} years, {result.months} months, {result.days} days
                </div>
                <div className="text-sm text-slate-600">
                  From {birthDate} to {targetDate}
                </div>
              </div>
              
              <div className="space-y-3">
                <div className="flex justify-between items-center p-3 bg-slate-50 rounded-lg">
                  <span className="text-slate-600">Total Days:</span>
                  <span className="font-semibold text-lg" data-testid="text-total-days">
                    {result.totalDays.toLocaleString()} days
                  </span>
                </div>
                <div className="flex justify-between items-center p-3 bg-slate-50 rounded-lg">
                  <span className="text-slate-600">Total Hours:</span>
                  <span className="font-semibold" data-testid="text-total-hours">
                    {(result.totalDays * 24).toLocaleString()} hours
                  </span>
                </div>
                <div className="flex justify-between items-center p-3 bg-slate-50 rounded-lg">
                  <span className="text-slate-600">Total Minutes:</span>
                  <span className="font-semibold" data-testid="text-total-minutes">
                    {(result.totalDays * 24 * 60).toLocaleString()} minutes
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {result && (
        <Card>
          <CardHeader>
            <CardTitle>Age Breakdown</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-3 gap-4 text-center">
              <div className="p-4 bg-blue-50 rounded-lg">
                <div className="text-2xl font-bold text-blue-600" data-testid="text-years-only">
                  {result.years}
                </div>
                <div className="text-sm text-slate-600">Years</div>
              </div>
              <div className="p-4 bg-green-50 rounded-lg">
                <div className="text-2xl font-bold text-green-600" data-testid="text-months-only">
                  {result.years * 12 + result.months}
                </div>
                <div className="text-sm text-slate-600">Total Months</div>
              </div>
              <div className="p-4 bg-purple-50 rounded-lg">
                <div className="text-2xl font-bold text-purple-600" data-testid="text-weeks-only">
                  {Math.floor(result.totalDays / 7)}
                </div>
                <div className="text-sm text-slate-600">Total Weeks</div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
