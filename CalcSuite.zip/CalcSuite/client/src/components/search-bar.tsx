import { Search } from 'lucide-react';
import { Input } from '@/components/ui/input';

interface SearchBarProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
}

export default function SearchBar({ value, onChange, placeholder = "Search..." }: SearchBarProps) {
  return (
    <div className="relative">
      <Input
        type="text"
        placeholder={placeholder}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full px-6 py-4 pl-14 text-lg rounded-2xl shadow-lg border-0 focus:ring-4 focus:ring-white/20 focus:outline-none"
        data-testid="input-search"
      />
      <Search className="absolute left-5 top-1/2 transform -translate-y-1/2 text-slate-400" size={20} />
    </div>
  );
}
