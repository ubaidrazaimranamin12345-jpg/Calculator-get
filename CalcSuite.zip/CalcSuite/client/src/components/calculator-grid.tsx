import { Link } from 'wouter';
import { Card, CardContent } from '@/components/ui/card';

interface Calculator {
  type: string;
  title: string;
  description: string;
  icon: string;
}

interface CalculatorGridProps {
  calculators: Calculator[];
  categoryColor: string;
}

const iconMap: { [key: string]: string } = {
  'home': '🏠',
  'hand-holding-usd': '💰',
  'chart-line': '📈',
  'piggy-bank': '🐷',
  'receipt': '🧾',
  'percentage': '%',
  'car': '🚗',
  'money-check-alt': '💵',
  'weight': '⚖️',
  'fire': '🔥',
  'tachometer-alt': '⏱️',
  'user': '👤',
  'balance-scale': '⚖️',
  'running': '🏃',
  'calculator': '🧮',
  'divide': '➗',
  'percent': '%',
  'play': '▶️',
  'dice': '🎲',
  'chart-bar': '📊',
  'calendar-alt': '📅',
  'calendar': '📆',
  'clock': '🕐',
  'graduation-cap': '🎓',
  'key': '🔑',
  'exchange-alt': '🔄',
  'network-wired': '🌐',
  'hammer': '🔨',
};

export default function CalculatorGrid({ calculators, categoryColor }: CalculatorGridProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
      {calculators.map((calculator) => (
        <Link key={calculator.type} href={`/calculator/${calculator.type}`}>
          <Card className="category-card cursor-pointer border border-slate-100 hover:shadow-xl transition-all duration-300" data-testid={`card-calculator-${calculator.type}`}>
            <CardContent className="p-6">
              <div className={`w-12 h-12 bg-${categoryColor}-bg rounded-xl flex items-center justify-center mb-4`}>
                <span className="text-2xl">{iconMap[calculator.icon] || '🧮'}</span>
              </div>
              <h4 className="font-semibold text-slate-900 mb-2">{calculator.title}</h4>
              <p className="text-slate-600 text-sm">{calculator.description}</p>
            </CardContent>
          </Card>
        </Link>
      ))}
    </div>
  );
}
