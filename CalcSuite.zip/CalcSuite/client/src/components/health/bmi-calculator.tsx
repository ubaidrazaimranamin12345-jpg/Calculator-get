import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { HealthCalculator } from '@/lib/calculations';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

export default function BMICalculator() {
  const [weight, setWeight] = useState('');
  const [height, setHeight] = useState('');
  const [unit, setUnit] = useState<'metric' | 'imperial'>('metric');
  const [result, setResult] = useState<{ bmi: number; category: string } | null>(null);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const saveCalculationMutation = useMutation({
    mutationFn: async (data: { type: string; expression: string; result: string; inputs: any }) => {
      return await apiRequest('POST', '/api/calculations', data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/calculations'] });
    },
  });

  const handleCalculate = () => {
    const w = parseFloat(weight);
    const h = parseFloat(height);

    if (isNaN(w) || isNaN(h) || w <= 0 || h <= 0) {
      toast({
        title: "Invalid Input",
        description: "Please enter valid positive numbers",
        variant: "destructive",
      });
      return;
    }

    const calculation = HealthCalculator.calculateBMI(w, h, unit);
    setResult(calculation);

    // Save to history
    const weightUnit = unit === 'metric' ? 'kg' : 'lbs';
    const heightUnit = unit === 'metric' ? 'm' : 'in';
    const expression = `BMI: ${w}${weightUnit}, ${h}${heightUnit}`;
    const resultText = `BMI: ${calculation.bmi} (${calculation.category})`;
    
    saveCalculationMutation.mutate({
      type: 'bmi',
      expression,
      result: resultText,
      inputs: { weight: w, height: h, unit },
    });
  };

  const handleReset = () => {
    setWeight('');
    setHeight('');
    setResult(null);
  };

  const getBMIColor = (bmi: number) => {
    if (bmi < 18.5) return 'text-blue-600';
    if (bmi < 25) return 'text-green-600';
    if (bmi < 30) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getBMIBgColor = (bmi: number) => {
    if (bmi < 18.5) return 'bg-blue-100';
    if (bmi < 25) return 'bg-green-100';
    if (bmi < 30) return 'bg-yellow-100';
    return 'bg-red-100';
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>BMI Calculation</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="unit">Unit System</Label>
              <Select value={unit} onValueChange={(value) => setUnit(value as 'metric' | 'imperial')}>
                <SelectTrigger data-testid="select-unit">
                  <SelectValue placeholder="Select unit system" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="metric">Metric (kg, m)</SelectItem>
                  <SelectItem value="imperial">Imperial (lbs, in)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="weight">
                Weight ({unit === 'metric' ? 'kg' : 'lbs'})
              </Label>
              <Input
                id="weight"
                type="number"
                step="0.1"
                value={weight}
                onChange={(e) => setWeight(e.target.value)}
                placeholder={unit === 'metric' ? 'e.g., 70' : 'e.g., 154'}
                data-testid="input-weight"
              />
            </div>
            <div>
              <Label htmlFor="height">
                Height ({unit === 'metric' ? 'm' : 'in'})
              </Label>
              <Input
                id="height"
                type="number"
                step="0.01"
                value={height}
                onChange={(e) => setHeight(e.target.value)}
                placeholder={unit === 'metric' ? 'e.g., 1.75' : 'e.g., 69'}
                data-testid="input-height"
              />
            </div>
            <div className="flex space-x-2">
              <Button onClick={handleCalculate} className="flex-1" data-testid="button-calculate">
                Calculate BMI
              </Button>
              <Button onClick={handleReset} variant="outline" data-testid="button-reset">
                Reset
              </Button>
            </div>
          </CardContent>
        </Card>

        {result && (
          <Card>
            <CardHeader>
              <CardTitle>Your BMI Result</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className={`p-6 rounded-lg ${getBMIBgColor(result.bmi)}`}>
                <div className="text-center">
                  <div className="text-sm text-slate-600 mb-1">Your BMI is</div>
                  <div className={`text-4xl font-bold ${getBMIColor(result.bmi)}`} data-testid="text-bmi-value">
                    {result.bmi}
                  </div>
                  <div className={`text-lg font-semibold ${getBMIColor(result.bmi)}`} data-testid="text-bmi-category">
                    {result.category}
                  </div>
                </div>
              </div>
              
              <div className="space-y-2 text-sm">
                <h4 className="font-semibold">BMI Categories:</h4>
                <div className="space-y-1">
                  <div className="flex justify-between">
                    <span className="text-blue-600">Underweight:</span>
                    <span>Below 18.5</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-green-600">Normal weight:</span>
                    <span>18.5 - 24.9</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-yellow-600">Overweight:</span>
                    <span>25 - 29.9</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-red-600">Obese:</span>
                    <span>30 and above</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {result && (
        <Card>
          <CardHeader>
            <CardTitle>About Your Result</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-sm text-slate-600">
              <p className="mb-2">
                Your BMI is <strong>{result.bmi}</strong>, which falls into the{' '}
                <strong className={getBMIColor(result.bmi)}>{result.category}</strong> category.
              </p>
              <p className="text-xs text-slate-500">
                BMI is a measure of body fat based on height and weight. It's a screening tool and 
                should not be used as a diagnostic tool. Consult with a healthcare provider for 
                personalized health advice.
              </p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
