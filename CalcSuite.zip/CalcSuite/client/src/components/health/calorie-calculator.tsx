import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { HealthCalculator } from '@/lib/calculations';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

export default function CalorieCalculator() {
  const [weight, setWeight] = useState('');
  const [height, setHeight] = useState('');
  const [age, setAge] = useState('');
  const [gender, setGender] = useState<'male' | 'female'>('male');
  const [activityLevel, setActivityLevel] = useState('sedentary');
  const [result, setResult] = useState<{ bmr: number; calories: number } | null>(null);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const saveCalculationMutation = useMutation({
    mutationFn: async (data: { type: string; expression: string; result: string; inputs: any }) => {
      return await apiRequest('POST', '/api/calculations', data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/calculations'] });
    },
  });

  const activityLevels = {
    sedentary: 'Sedentary (little/no exercise)',
    light: 'Light activity (light exercise 1-3 days/week)',
    moderate: 'Moderate activity (moderate exercise 3-5 days/week)',
    active: 'Active (heavy exercise 6-7 days/week)',
    veryActive: 'Very active (very heavy exercise, physical job)',
  };

  const handleCalculate = () => {
    const w = parseFloat(weight);
    const h = parseFloat(height);
    const a = parseFloat(age);

    if (isNaN(w) || isNaN(h) || isNaN(a) || w <= 0 || h <= 0 || a <= 0) {
      toast({
        title: "Invalid Input",
        description: "Please enter valid positive numbers",
        variant: "destructive",
      });
      return;
    }

    const bmr = HealthCalculator.calculateBMR(w, h, a, gender);
    const calories = HealthCalculator.calculateCalories(bmr, activityLevel);
    setResult({ bmr, calories });

    // Save to history
    const expression = `Calories: ${gender}, ${a}y, ${w}kg, ${h}cm, ${activityLevels[activityLevel as keyof typeof activityLevels]}`;
    const resultText = `${calories} calories/day (BMR: ${bmr})`;
    
    saveCalculationMutation.mutate({
      type: 'calorie',
      expression,
      result: resultText,
      inputs: { weight: w, height: h, age: a, gender, activityLevel },
    });
  };

  const handleReset = () => {
    setWeight('');
    setHeight('');
    setAge('');
    setGender('male');
    setActivityLevel('sedentary');
    setResult(null);
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Personal Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label>Gender</Label>
              <RadioGroup value={gender} onValueChange={(value) => setGender(value as 'male' | 'female')} className="flex space-x-4 mt-2">
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="male" id="male" data-testid="radio-male" />
                  <Label htmlFor="male">Male</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="female" id="female" data-testid="radio-female" />
                  <Label htmlFor="female">Female</Label>
                </div>
              </RadioGroup>
            </div>
            <div>
              <Label htmlFor="age">Age (years)</Label>
              <Input
                id="age"
                type="number"
                value={age}
                onChange={(e) => setAge(e.target.value)}
                placeholder="e.g., 30"
                data-testid="input-age"
              />
            </div>
            <div>
              <Label htmlFor="weight">Weight (kg)</Label>
              <Input
                id="weight"
                type="number"
                step="0.1"
                value={weight}
                onChange={(e) => setWeight(e.target.value)}
                placeholder="e.g., 70"
                data-testid="input-weight"
              />
            </div>
            <div>
              <Label htmlFor="height">Height (cm)</Label>
              <Input
                id="height"
                type="number"
                value={height}
                onChange={(e) => setHeight(e.target.value)}
                placeholder="e.g., 175"
                data-testid="input-height"
              />
            </div>
            <div>
              <Label htmlFor="activity">Activity Level</Label>
              <Select value={activityLevel} onValueChange={setActivityLevel}>
                <SelectTrigger data-testid="select-activity">
                  <SelectValue placeholder="Select activity level" />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(activityLevels).map(([key, label]) => (
                    <SelectItem key={key} value={key}>{label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex space-x-2">
              <Button onClick={handleCalculate} className="flex-1" data-testid="button-calculate">
                Calculate
              </Button>
              <Button onClick={handleReset} variant="outline" data-testid="button-reset">
                Reset
              </Button>
            </div>
          </CardContent>
        </Card>

        {result && (
          <Card>
            <CardHeader>
              <CardTitle>Your Daily Calorie Needs</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-4 bg-primary/10 rounded-lg">
                <div className="text-sm text-slate-600">Daily Calories</div>
                <div className="text-3xl font-bold text-primary" data-testid="text-calories">
                  {result.calories} cal/day
                </div>
              </div>
              <div className="p-4 bg-slate-50 rounded-lg">
                <div className="text-sm text-slate-600">Basal Metabolic Rate</div>
                <div className="text-xl font-semibold" data-testid="text-bmr">
                  {result.bmr} cal/day
                </div>
                <div className="text-xs text-slate-500 mt-1">
                  Calories burned at rest
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {result && (
        <Card>
          <CardHeader>
            <CardTitle>Calorie Goals</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
              <div className="p-4 bg-red-50 rounded-lg">
                <div className="text-sm text-slate-600">Weight Loss</div>
                <div className="text-lg font-semibold text-red-600" data-testid="text-weight-loss">
                  {result.calories - 500} cal/day
                </div>
                <div className="text-xs text-slate-500">-1 lb/week</div>
              </div>
              <div className="p-4 bg-green-50 rounded-lg">
                <div className="text-sm text-slate-600">Maintain Weight</div>
                <div className="text-lg font-semibold text-green-600" data-testid="text-maintain">
                  {result.calories} cal/day
                </div>
                <div className="text-xs text-slate-500">Current weight</div>
              </div>
              <div className="p-4 bg-blue-50 rounded-lg">
                <div className="text-sm text-slate-600">Weight Gain</div>
                <div className="text-lg font-semibold text-blue-600" data-testid="text-weight-gain">
                  {result.calories + 500} cal/day
                </div>
                <div className="text-xs text-slate-500">+1 lb/week</div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
