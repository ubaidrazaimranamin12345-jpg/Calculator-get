import { evaluate } from 'mathjs';

export class Calculator {
  static evaluate(expression: string): string {
    try {
      // Replace common symbols
      const cleanExpression = expression
        .replace(/×/g, '*')
        .replace(/÷/g, '/')
        .replace(/π/g, 'pi')
        .replace(/e/g, 'e');
      
      const result = evaluate(cleanExpression);
      return typeof result === 'number' ? result.toString() : String(result);
    } catch (error) {
      throw new Error('Invalid expression');
    }
  }

  static formatResult(result: number, decimals: number = 10): string {
    if (Number.isInteger(result)) {
      return result.toString();
    }
    return parseFloat(result.toFixed(decimals)).toString();
  }
}

export class FinancialCalculator {
  static calculateMortgage(principal: number, rate: number, years: number): {
    monthlyPayment: number;
    totalPayment: number;
    totalInterest: number;
  } {
    const monthlyRate = rate / 100 / 12;
    const numPayments = years * 12;
    
    const monthlyPayment = principal * 
      (monthlyRate * Math.pow(1 + monthlyRate, numPayments)) / 
      (Math.pow(1 + monthlyRate, numPayments) - 1);
    
    const totalPayment = monthlyPayment * numPayments;
    const totalInterest = totalPayment - principal;
    
    return {
      monthlyPayment: Math.round(monthlyPayment * 100) / 100,
      totalPayment: Math.round(totalPayment * 100) / 100,
      totalInterest: Math.round(totalInterest * 100) / 100,
    };
  }

  static calculateLoan(principal: number, rate: number, months: number): {
    monthlyPayment: number;
    totalPayment: number;
    totalInterest: number;
  } {
    const monthlyRate = rate / 100 / 12;
    
    const monthlyPayment = principal * 
      (monthlyRate * Math.pow(1 + monthlyRate, months)) / 
      (Math.pow(1 + monthlyRate, months) - 1);
    
    const totalPayment = monthlyPayment * months;
    const totalInterest = totalPayment - principal;
    
    return {
      monthlyPayment: Math.round(monthlyPayment * 100) / 100,
      totalPayment: Math.round(totalPayment * 100) / 100,
      totalInterest: Math.round(totalInterest * 100) / 100,
    };
  }
}

export class HealthCalculator {
  static calculateBMI(weight: number, height: number, unit: 'metric' | 'imperial' = 'metric'): {
    bmi: number;
    category: string;
  } {
    let bmi: number;
    
    if (unit === 'imperial') {
      // weight in pounds, height in inches
      bmi = (weight / (height * height)) * 703;
    } else {
      // weight in kg, height in meters
      bmi = weight / (height * height);
    }
    
    let category: string;
    if (bmi < 18.5) category = 'Underweight';
    else if (bmi < 25) category = 'Normal weight';
    else if (bmi < 30) category = 'Overweight';
    else category = 'Obese';
    
    return {
      bmi: Math.round(bmi * 10) / 10,
      category,
    };
  }

  static calculateBMR(weight: number, height: number, age: number, gender: 'male' | 'female'): number {
    let bmr: number;
    
    if (gender === 'male') {
      bmr = 88.362 + (13.397 * weight) + (4.799 * height) - (5.677 * age);
    } else {
      bmr = 447.593 + (9.247 * weight) + (3.098 * height) - (4.330 * age);
    }
    
    return Math.round(bmr);
  }

  static calculateCalories(bmr: number, activityLevel: string): number {
    const multipliers: { [key: string]: number } = {
      sedentary: 1.2,
      light: 1.375,
      moderate: 1.55,
      active: 1.725,
      veryActive: 1.9,
    };
    
    return Math.round(bmr * (multipliers[activityLevel] || 1.2));
  }
}

export class MathCalculator {
  static calculatePercentage(value: number, percentage: number): number {
    return (value * percentage) / 100;
  }

  static percentageIncrease(original: number, increased: number): number {
    return ((increased - original) / original) * 100;
  }

  static percentageDecrease(original: number, decreased: number): number {
    return ((original - decreased) / original) * 100;
  }

  static generateRandomNumber(min: number, max: number): number {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }
}

export class UtilityCalculator {
  static calculateAge(birthDate: Date): {
    years: number;
    months: number;
    days: number;
  } {
    const today = new Date();
    const birth = new Date(birthDate);
    
    let years = today.getFullYear() - birth.getFullYear();
    let months = today.getMonth() - birth.getMonth();
    let days = today.getDate() - birth.getDate();
    
    if (days < 0) {
      months--;
      const lastMonth = new Date(today.getFullYear(), today.getMonth(), 0);
      days += lastMonth.getDate();
    }
    
    if (months < 0) {
      years--;
      months += 12;
    }
    
    return { years, months, days };
  }

  static addDaysToDate(date: Date, days: number): Date {
    const result = new Date(date);
    result.setDate(result.getDate() + days);
    return result;
  }

  static subtractDaysFromDate(date: Date, days: number): Date {
    const result = new Date(date);
    result.setDate(result.getDate() - days);
    return result;
  }

  static generatePassword(length: number = 12, includeSymbols: boolean = true): string {
    const lowercase = 'abcdefghijklmnopqrstuvwxyz';
    const uppercase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const numbers = '0123456789';
    const symbols = '!@#$%^&*()_+-=[]{}|;:,.<>?';
    
    let chars = lowercase + uppercase + numbers;
    if (includeSymbols) chars += symbols;
    
    let password = '';
    for (let i = 0; i < length; i++) {
      password += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    
    return password;
  }
}
