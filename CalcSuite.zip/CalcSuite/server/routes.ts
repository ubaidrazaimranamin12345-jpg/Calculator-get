import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertCalculationSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all calculations
  app.get("/api/calculations", async (req, res) => {
    try {
      const calculations = await storage.getCalculations();
      res.json(calculations);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch calculations" });
    }
  });

  // Get calculations by type
  app.get("/api/calculations/:type", async (req, res) => {
    try {
      const { type } = req.params;
      const calculations = await storage.getCalculationsByType(type);
      res.json(calculations);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch calculations by type" });
    }
  });

  // Create a new calculation
  app.post("/api/calculations", async (req, res) => {
    try {
      const validatedData = insertCalculationSchema.parse(req.body);
      const calculation = await storage.createCalculation(validatedData);
      res.status(201).json(calculation);
    } catch (error) {
      if (error instanceof Error) {
        res.status(400).json({ message: error.message });
      } else {
        res.status(500).json({ message: "Failed to create calculation" });
      }
    }
  });

  // Delete a calculation
  app.delete("/api/calculations/:id", async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deleteCalculation(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete calculation" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
