import { type Calculation, type InsertCalculation } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getCalculations(): Promise<Calculation[]>;
  getCalculationsByType(type: string): Promise<Calculation[]>;
  createCalculation(calculation: InsertCalculation): Promise<Calculation>;
  deleteCalculation(id: string): Promise<void>;
}

export class MemStorage implements IStorage {
  private calculations: Map<string, Calculation>;

  constructor() {
    this.calculations = new Map();
  }

  async getCalculations(): Promise<Calculation[]> {
    return Array.from(this.calculations.values()).sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async getCalculationsByType(type: string): Promise<Calculation[]> {
    return Array.from(this.calculations.values())
      .filter((calc) => calc.type === type)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async createCalculation(insertCalculation: InsertCalculation): Promise<Calculation> {
    const id = randomUUID();
    const calculation: Calculation = {
      ...insertCalculation,
      inputs: insertCalculation.inputs || null,
      id,
      createdAt: new Date(),
    };
    this.calculations.set(id, calculation);
    return calculation;
  }

  async deleteCalculation(id: string): Promise<void> {
    this.calculations.delete(id);
  }
}

export const storage = new MemStorage();
