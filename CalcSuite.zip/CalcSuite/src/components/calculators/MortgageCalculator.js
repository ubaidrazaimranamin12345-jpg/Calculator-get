import React, { useState } from 'react';

const MortgageCalculator = () => {
  const [principal, setPrincipal] = useState('');
  const [interestRate, setInterestRate] = useState('');
  const [loanTerm, setLoanTerm] = useState('');
  const [results, setResults] = useState(null);

  const calculateMortgage = () => {
    const P = parseFloat(principal);
    const r = parseFloat(interestRate) / 100 / 12; // Monthly interest rate
    const n = parseFloat(loanTerm) * 12; // Total number of payments

    if (P && r && n) {
      // Monthly payment formula: M = P * [r(1+r)^n] / [(1+r)^n - 1]
      const monthlyPayment = P * (r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
      const totalPayment = monthlyPayment * n;
      const totalInterest = totalPayment - P;

      setResults({
        monthlyPayment: monthlyPayment.toFixed(2),
        totalPayment: totalPayment.toFixed(2),
        totalInterest: totalInterest.toFixed(2)
      });
    }
  };

  const reset = () => {
    setPrincipal('');
    setInterestRate('');
    setLoanTerm('');
    setResults(null);
  };

  return (
    <div className="calculator-container fade-in">
      <div className="calculator-header">
        <h2>Mortgage Calculator</h2>
        <p>Calculate your monthly mortgage payments</p>
      </div>
      
      <div className="calculator-body">
        <div className="form-group">
          <label htmlFor="principal">Loan Amount ($)</label>
          <input
            id="principal"
            type="number"
            className="form-input"
            value={principal}
            onChange={(e) => setPrincipal(e.target.value)}
            placeholder="e.g., 300000"
          />
        </div>

        <div className="form-group">
          <label htmlFor="interest">Annual Interest Rate (%)</label>
          <input
            id="interest"
            type="number"
            step="0.01"
            className="form-input"
            value={interestRate}
            onChange={(e) => setInterestRate(e.target.value)}
            placeholder="e.g., 4.5"
          />
        </div>

        <div className="form-group">
          <label htmlFor="term">Loan Term (years)</label>
          <input
            id="term"
            type="number"
            className="form-input"
            value={loanTerm}
            onChange={(e) => setLoanTerm(e.target.value)}
            placeholder="e.g., 30"
          />
        </div>

        <div className="form-buttons">
          <button className="btn btn-primary" onClick={calculateMortgage}>
            Calculate
          </button>
          <button className="btn btn-secondary" onClick={reset}>
            Reset
          </button>
        </div>

        {results && (
          <div className="results-container slide-in">
            <h3 style={{ marginBottom: '1.5rem', color: '#0369a1' }}>Payment Breakdown</h3>
            
            <div className="result-item">
              <span className="result-label">Monthly Payment:</span>
              <span className="result-value">${results.monthlyPayment}</span>
            </div>
            
            <div className="result-item">
              <span className="result-label">Total Payment:</span>
              <span className="result-value">${results.totalPayment}</span>
            </div>
            
            <div className="result-item">
              <span className="result-label">Total Interest:</span>
              <span className="result-value">${results.totalInterest}</span>
            </div>

            <div style={{ marginTop: '2rem', padding: '1rem', backgroundColor: 'rgba(59, 130, 246, 0.1)', borderRadius: '10px', fontSize: '0.9rem', color: '#1e40af' }}>
              <strong>Summary:</strong> For a loan of ${parseFloat(principal).toLocaleString()} at {interestRate}% interest over {loanTerm} years, you'll pay ${results.monthlyPayment} per month, with a total interest of ${parseFloat(results.totalInterest).toLocaleString()}.
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default MortgageCalculator;