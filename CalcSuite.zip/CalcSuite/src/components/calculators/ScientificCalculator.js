import React, { useState } from 'react';

const ScientificCalculator = () => {
  const [display, setDisplay] = useState('0');
  const [expression, setExpression] = useState('');
  const [angleMode, setAngleMode] = useState('deg'); // 'deg' or 'rad'

  const inputNumber = (num) => {
    setDisplay(display === '0' ? num : display + num);
  };

  const inputOperator = (operator) => {
    setExpression(expression + display + ' ' + operator + ' ');
    setDisplay('0');
  };

  const inputFunction = (func) => {
    try {
      const value = parseFloat(display);
      let result;

      switch (func) {
        case 'sin':
          result = Math.sin(angleMode === 'deg' ? value * Math.PI / 180 : value);
          break;
        case 'cos':
          result = Math.cos(angleMode === 'deg' ? value * Math.PI / 180 : value);
          break;
        case 'tan':
          result = Math.tan(angleMode === 'deg' ? value * Math.PI / 180 : value);
          break;
        case 'log':
          result = Math.log10(value);
          break;
        case 'ln':
          result = Math.log(value);
          break;
        case 'sqrt':
          result = Math.sqrt(value);
          break;
        case 'square':
          result = value * value;
          break;
        case 'cube':
          result = value * value * value;
          break;
        case 'factorial':
          result = factorial(value);
          break;
        case 'reciprocal':
          result = 1 / value;
          break;
        case 'exp':
          result = Math.exp(value);
          break;
        default:
          result = value;
      }

      setDisplay(result.toString());
    } catch (error) {
      setDisplay('Error');
    }
  };

  const factorial = (n) => {
    if (n < 0 || !Number.isInteger(n)) return NaN;
    if (n === 0 || n === 1) return 1;
    let result = 1;
    for (let i = 2; i <= n; i++) {
      result *= i;
    }
    return result;
  };

  const inputConstant = (constant) => {
    switch (constant) {
      case 'pi':
        setDisplay(Math.PI.toString());
        break;
      case 'e':
        setDisplay(Math.E.toString());
        break;
    }
  };

  const calculate = () => {
    try {
      const fullExpression = expression + display;
      // Simple expression evaluation (in production, use a proper math parser)
      const result = eval(fullExpression.replace(/×/g, '*').replace(/÷/g, '/'));
      setDisplay(result.toString());
      setExpression('');
    } catch (error) {
      setDisplay('Error');
    }
  };

  const clear = () => {
    setDisplay('0');
    setExpression('');
  };

  const toggleAngleMode = () => {
    setAngleMode(angleMode === 'deg' ? 'rad' : 'deg');
  };

  return (
    <div className="calculator-container scientific-calculator fade-in">
      <div className="calculator-header">
        <h2>Scientific Calculator</h2>
        <p>Advanced mathematical functions</p>
      </div>
      
      <div className="calculator-body">
        <div className="calculator-display">
          <div className="expression">{expression || ' '}</div>
          <div className="result">{display}</div>
          <div style={{ textAlign: 'right', marginTop: '0.5rem' }}>
            <button 
              onClick={toggleAngleMode}
              style={{
                background: 'none',
                border: '1px solid rgba(255,255,255,0.3)',
                color: '#a0aec0',
                padding: '0.25rem 0.5rem',
                borderRadius: '4px',
                fontSize: '0.75rem'
              }}
            >
              {angleMode.toUpperCase()}
            </button>
          </div>
        </div>

        <div className="calculator-buttons">
          {/* Row 1: Trigonometric Functions */}
          <button className="calc-btn function" onClick={() => inputFunction('sin')}>sin</button>
          <button className="calc-btn function" onClick={() => inputFunction('cos')}>cos</button>
          <button className="calc-btn function" onClick={() => inputFunction('tan')}>tan</button>
          <button className="calc-btn function" onClick={() => inputFunction('log')}>log</button>
          <button className="calc-btn function" onClick={() => inputFunction('ln')}>ln</button>
          <button className="calc-btn clear" onClick={clear}>C</button>

          {/* Row 2: Powers and Roots */}
          <button className="calc-btn function" onClick={() => inputConstant('pi')}>π</button>
          <button className="calc-btn function" onClick={() => inputConstant('e')}>e</button>
          <button className="calc-btn function" onClick={() => inputFunction('square')}>x²</button>
          <button className="calc-btn function" onClick={() => inputFunction('cube')}>x³</button>
          <button className="calc-btn function" onClick={() => inputFunction('sqrt')}>√x</button>
          <button className="calc-btn operator" onClick={() => inputOperator('÷')}>÷</button>

          {/* Row 3: Numbers and Operators */}
          <button className="calc-btn function" onClick={() => inputFunction('factorial')}>x!</button>
          <button className="calc-btn function" onClick={() => inputFunction('reciprocal')}>1/x</button>
          <button className="calc-btn function" onClick={() => inputFunction('exp')}>exp</button>
          <button className="calc-btn number" onClick={() => inputNumber('7')}>7</button>
          <button className="calc-btn number" onClick={() => inputNumber('8')}>8</button>
          <button className="calc-btn number" onClick={() => inputNumber('9')}>9</button>

          {/* Row 4 */}
          <button className="calc-btn operator" onClick={() => inputOperator('×')}>×</button>
          <button className="calc-btn number" onClick={() => inputNumber('4')}>4</button>
          <button className="calc-btn number" onClick={() => inputNumber('5')}>5</button>
          <button className="calc-btn number" onClick={() => inputNumber('6')}>6</button>
          <button className="calc-btn operator" onClick={() => inputOperator('-')}>-</button>
          <button className="calc-btn number" onClick={() => inputNumber('1')}>1</button>

          {/* Row 5 */}
          <button className="calc-btn number" onClick={() => inputNumber('2')}>2</button>
          <button className="calc-btn number" onClick={() => inputNumber('3')}>3</button>
          <button className="calc-btn operator" onClick={() => inputOperator('+')}>+</button>
          <button className="calc-btn number" onClick={() => inputNumber('0')} style={{ gridColumn: 'span 2' }}>0</button>
          <button className="calc-btn number" onClick={() => inputNumber('.')}>.</button>
          <button className="calc-btn equals" onClick={calculate}>=</button>
        </div>
      </div>
    </div>
  );
};

export default ScientificCalculator;