import React, { useState } from 'react';

const BMICalculator = () => {
  const [weight, setWeight] = useState('');
  const [height, setHeight] = useState('');
  const [unit, setUnit] = useState('metric'); // 'metric' or 'imperial'
  const [results, setResults] = useState(null);

  const calculateBMI = () => {
    const w = parseFloat(weight);
    const h = parseFloat(height);

    if (w && h) {
      let bmi;
      
      if (unit === 'metric') {
        // BMI = weight (kg) / height² (m²)
        bmi = w / (h * h);
      } else {
        // BMI = (weight (lbs) / height² (in²)) × 703
        bmi = (w / (h * h)) * 703;
      }

      let category = '';
      let color = '';
      
      if (bmi < 18.5) {
        category = 'Underweight';
        color = '#3b82f6';
      } else if (bmi < 25) {
        category = 'Normal weight';
        color = '#10b981';
      } else if (bmi < 30) {
        category = 'Overweight';
        color = '#f59e0b';
      } else {
        category = 'Obese';
        color = '#ef4444';
      }

      setResults({
        bmi: bmi.toFixed(1),
        category,
        color
      });
    }
  };

  const reset = () => {
    setWeight('');
    setHeight('');
    setResults(null);
  };

  return (
    <div className="calculator-container fade-in">
      <div className="calculator-header">
        <h2>BMI Calculator</h2>
        <p>Body Mass Index calculator with health categories</p>
      </div>
      
      <div className="calculator-body">
        <div className="form-group">
          <label htmlFor="unit">Unit System</label>
          <select 
            id="unit"
            className="form-select"
            value={unit}
            onChange={(e) => setUnit(e.target.value)}
          >
            <option value="metric">Metric (kg, m)</option>
            <option value="imperial">Imperial (lbs, in)</option>
          </select>
        </div>

        <div className="form-group">
          <label htmlFor="weight">
            Weight ({unit === 'metric' ? 'kg' : 'lbs'})
          </label>
          <input
            id="weight"
            type="number"
            step="0.1"
            className="form-input"
            value={weight}
            onChange={(e) => setWeight(e.target.value)}
            placeholder={unit === 'metric' ? 'e.g., 70' : 'e.g., 154'}
          />
        </div>

        <div className="form-group">
          <label htmlFor="height">
            Height ({unit === 'metric' ? 'm' : 'in'})
          </label>
          <input
            id="height"
            type="number"
            step={unit === 'metric' ? '0.01' : '1'}
            className="form-input"
            value={height}
            onChange={(e) => setHeight(e.target.value)}
            placeholder={unit === 'metric' ? 'e.g., 1.75' : 'e.g., 69'}
          />
        </div>

        <div className="form-buttons">
          <button className="btn btn-primary" onClick={calculateBMI}>
            Calculate BMI
          </button>
          <button className="btn btn-secondary" onClick={reset}>
            Reset
          </button>
        </div>

        {results && (
          <div className="results-container slide-in">
            <div style={{ 
              textAlign: 'center', 
              padding: '2rem', 
              backgroundColor: `${results.color}20`,
              borderRadius: '15px',
              border: `2px solid ${results.color}40`,
              marginBottom: '2rem'
            }}>
              <div style={{ fontSize: '3rem', fontWeight: '700', color: results.color, marginBottom: '0.5rem' }}>
                {results.bmi}
              </div>
              <div style={{ fontSize: '1.5rem', fontWeight: '600', color: results.color }}>
                {results.category}
              </div>
            </div>

            <div style={{ marginBottom: '2rem' }}>
              <h3 style={{ marginBottom: '1rem', color: '#0369a1' }}>BMI Categories:</h3>
              <div style={{ display: 'grid', gap: '0.5rem', fontSize: '0.9rem' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span style={{ color: '#3b82f6' }}>Underweight:</span>
                  <span>Below 18.5</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span style={{ color: '#10b981' }}>Normal weight:</span>
                  <span>18.5 - 24.9</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span style={{ color: '#f59e0b' }}>Overweight:</span>
                  <span>25 - 29.9</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span style={{ color: '#ef4444' }}>Obese:</span>
                  <span>30 and above</span>
                </div>
              </div>
            </div>

            <div style={{ padding: '1rem', backgroundColor: 'rgba(148, 163, 184, 0.1)', borderRadius: '10px', fontSize: '0.85rem', color: '#475569' }}>
              <strong>Note:</strong> BMI is a screening tool and should not be used as a diagnostic tool. It doesn't account for muscle mass, bone density, or overall body composition. Consult with a healthcare professional for personalized health advice.
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default BMICalculator;