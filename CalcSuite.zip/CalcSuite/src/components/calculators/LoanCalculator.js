import React, { useState } from 'react';

const LoanCalculator = () => {
  const [loanAmount, setLoanAmount] = useState('');
  const [interestRate, setInterestRate] = useState('');
  const [loanTerm, setLoanTerm] = useState('');
  const [results, setResults] = useState(null);

  const calculateLoan = () => {
    const P = parseFloat(loanAmount);
    const r = parseFloat(interestRate) / 100 / 12; // Monthly interest rate
    const n = parseFloat(loanTerm); // Number of months

    if (P && r && n) {
      // Monthly payment formula
      const monthlyPayment = P * (r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
      const totalPayment = monthlyPayment * n;
      const totalInterest = totalPayment - P;

      setResults({
        monthlyPayment: monthlyPayment.toFixed(2),
        totalPayment: totalPayment.toFixed(2),
        totalInterest: totalInterest.toFixed(2)
      });
    }
  };

  const reset = () => {
    setLoanAmount('');
    setInterestRate('');
    setLoanTerm('');
    setResults(null);
  };

  return (
    <div className="calculator-container fade-in">
      <div className="calculator-header">
        <h2>Loan Calculator</h2>
        <p>Calculate personal and business loan payments</p>
      </div>
      
      <div className="calculator-body">
        <div className="form-group">
          <label htmlFor="amount">Loan Amount ($)</label>
          <input
            id="amount"
            type="number"
            className="form-input"
            value={loanAmount}
            onChange={(e) => setLoanAmount(e.target.value)}
            placeholder="e.g., 25000"
          />
        </div>

        <div className="form-group">
          <label htmlFor="rate">Annual Interest Rate (%)</label>
          <input
            id="rate"
            type="number"
            step="0.01"
            className="form-input"
            value={interestRate}
            onChange={(e) => setInterestRate(e.target.value)}
            placeholder="e.g., 6.5"
          />
        </div>

        <div className="form-group">
          <label htmlFor="months">Loan Term (months)</label>
          <input
            id="months"
            type="number"
            className="form-input"
            value={loanTerm}
            onChange={(e) => setLoanTerm(e.target.value)}
            placeholder="e.g., 60"
          />
        </div>

        <div className="form-buttons">
          <button className="btn btn-primary" onClick={calculateLoan}>
            Calculate
          </button>
          <button className="btn btn-secondary" onClick={reset}>
            Reset
          </button>
        </div>

        {results && (
          <div className="results-container slide-in">
            <h3 style={{ marginBottom: '1.5rem', color: '#0369a1' }}>Loan Payment Details</h3>
            
            <div className="result-item">
              <span className="result-label">Monthly Payment:</span>
              <span className="result-value">${results.monthlyPayment}</span>
            </div>
            
            <div className="result-item">
              <span className="result-label">Total Payment:</span>
              <span className="result-value">${results.totalPayment}</span>
            </div>
            
            <div className="result-item">
              <span className="result-label">Total Interest:</span>
              <span className="result-value">${results.totalInterest}</span>
            </div>

            <div style={{ marginTop: '2rem', padding: '1rem', backgroundColor: 'rgba(16, 185, 129, 0.1)', borderRadius: '10px', fontSize: '0.9rem', color: '#047857' }}>
              <strong>Summary:</strong> For a ${parseFloat(loanAmount).toLocaleString()} loan at {interestRate}% interest over {loanTerm} months, you'll pay ${results.monthlyPayment} per month. Total interest cost will be ${parseFloat(results.totalInterest).toLocaleString()}.
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default LoanCalculator;