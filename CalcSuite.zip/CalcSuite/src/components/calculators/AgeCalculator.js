import React, { useState } from 'react';

const AgeCalculator = () => {
  const [birthDate, setBirthDate] = useState('');
  const [targetDate, setTargetDate] = useState(new Date().toISOString().split('T')[0]);
  const [results, setResults] = useState(null);

  const calculateAge = () => {
    if (birthDate && targetDate) {
      const birth = new Date(birthDate);
      const target = new Date(targetDate);

      if (birth > target) {
        alert('Birth date cannot be after target date');
        return;
      }

      // Calculate exact age
      let years = target.getFullYear() - birth.getFullYear();
      let months = target.getMonth() - birth.getMonth();
      let days = target.getDate() - birth.getDate();

      if (days < 0) {
        months--;
        const daysInPrevMonth = new Date(target.getFullYear(), target.getMonth(), 0).getDate();
        days += daysInPrevMonth;
      }

      if (months < 0) {
        years--;
        months += 12;
      }

      // Calculate total time units
      const totalDays = Math.floor((target - birth) / (1000 * 60 * 60 * 24));
      const totalHours = totalDays * 24;
      const totalMinutes = totalHours * 60;
      const totalWeeks = Math.floor(totalDays / 7);

      setResults({
        years,
        months,
        days,
        totalDays,
        totalWeeks,
        totalHours: totalHours.toLocaleString(),
        totalMinutes: totalMinutes.toLocaleString()
      });
    }
  };

  const useToday = () => {
    setTargetDate(new Date().toISOString().split('T')[0]);
  };

  const reset = () => {
    setBirthDate('');
    setTargetDate(new Date().toISOString().split('T')[0]);
    setResults(null);
  };

  return (
    <div className="calculator-container fade-in">
      <div className="calculator-header">
        <h2>Age Calculator</h2>
        <p>Calculate exact age in years, months, and days</p>
      </div>
      
      <div className="calculator-body">
        <div className="form-group">
          <label htmlFor="birthDate">Birth Date</label>
          <input
            id="birthDate"
            type="date"
            className="form-input"
            value={birthDate}
            onChange={(e) => setBirthDate(e.target.value)}
          />
        </div>

        <div className="form-group">
          <label htmlFor="targetDate">Target Date</label>
          <div style={{ display: 'flex', gap: '0.5rem' }}>
            <input
              id="targetDate"
              type="date"
              className="form-input"
              value={targetDate}
              onChange={(e) => setTargetDate(e.target.value)}
              style={{ flex: 1 }}
            />
            <button 
              type="button"
              onClick={useToday}
              style={{
                padding: '0.5rem 1rem',
                background: '#f1f5f9',
                border: '2px solid #e2e8f0',
                borderRadius: '10px',
                cursor: 'pointer',
                fontSize: '0.9rem',
                whiteSpace: 'nowrap'
              }}
            >
              Use Today
            </button>
          </div>
        </div>

        <div className="form-buttons">
          <button className="btn btn-primary" onClick={calculateAge}>
            Calculate Age
          </button>
          <button className="btn btn-secondary" onClick={reset}>
            Reset
          </button>
        </div>

        {results && (
          <div className="results-container slide-in">
            <div style={{ 
              textAlign: 'center', 
              padding: '2rem', 
              backgroundColor: 'rgba(139, 92, 246, 0.1)',
              borderRadius: '15px',
              marginBottom: '2rem'
            }}>
              <div style={{ fontSize: '2.5rem', fontWeight: '700', color: '#7c3aed', marginBottom: '0.5rem' }}>
                {results.years} years, {results.months} months, {results.days} days
              </div>
              <div style={{ color: '#64748b' }}>Exact Age</div>
            </div>

            <h3 style={{ marginBottom: '1.5rem', color: '#0369a1' }}>Detailed Breakdown</h3>
            
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1rem', marginBottom: '2rem' }}>
              <div style={{ 
                textAlign: 'center', 
                padding: '1.5rem', 
                backgroundColor: 'rgba(59, 130, 246, 0.1)',
                borderRadius: '10px'
              }}>
                <div style={{ fontSize: '2rem', fontWeight: '700', color: '#2563eb' }}>
                  {results.totalDays.toLocaleString()}
                </div>
                <div style={{ color: '#64748b' }}>Total Days</div>
              </div>

              <div style={{ 
                textAlign: 'center', 
                padding: '1.5rem', 
                backgroundColor: 'rgba(16, 185, 129, 0.1)',
                borderRadius: '10px'
              }}>
                <div style={{ fontSize: '2rem', fontWeight: '700', color: '#059669' }}>
                  {results.totalWeeks.toLocaleString()}
                </div>
                <div style={{ color: '#64748b' }}>Total Weeks</div>
              </div>

              <div style={{ 
                textAlign: 'center', 
                padding: '1.5rem', 
                backgroundColor: 'rgba(245, 158, 11, 0.1)',
                borderRadius: '10px'
              }}>
                <div style={{ fontSize: '1.5rem', fontWeight: '700', color: '#d97706' }}>
                  {results.totalHours}
                </div>
                <div style={{ color: '#64748b' }}>Total Hours</div>
              </div>

              <div style={{ 
                textAlign: 'center', 
                padding: '1.5rem', 
                backgroundColor: 'rgba(239, 68, 68, 0.1)',
                borderRadius: '10px'
              }}>
                <div style={{ fontSize: '1.25rem', fontWeight: '700', color: '#dc2626' }}>
                  {results.totalMinutes}
                </div>
                <div style={{ color: '#64748b' }}>Total Minutes</div>
              </div>
            </div>

            <div style={{ 
              padding: '1rem', 
              backgroundColor: 'rgba(139, 92, 246, 0.1)', 
              borderRadius: '10px', 
              fontSize: '0.9rem', 
              color: '#6d28d9' 
            }}>
              <strong>Summary:</strong> From {birthDate} to {targetDate}, you are exactly {results.years} years, {results.months} months, and {results.days} days old. That's a total of {results.totalDays.toLocaleString()} days you've been alive!
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AgeCalculator;