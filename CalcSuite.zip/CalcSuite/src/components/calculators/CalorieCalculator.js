import React, { useState } from 'react';

const CalorieCalculator = () => {
  const [age, setAge] = useState('');
  const [gender, setGender] = useState('male');
  const [weight, setWeight] = useState('');
  const [height, setHeight] = useState('');
  const [activity, setActivity] = useState('sedentary');
  const [results, setResults] = useState(null);

  const activityLevels = {
    sedentary: { label: 'Sedentary (little/no exercise)', multiplier: 1.2 },
    light: { label: 'Light activity (light exercise 1-3 days/week)', multiplier: 1.375 },
    moderate: { label: 'Moderate activity (moderate exercise 3-5 days/week)', multiplier: 1.55 },
    active: { label: 'Active (heavy exercise 6-7 days/week)', multiplier: 1.725 },
    veryActive: { label: 'Very active (very heavy exercise, physical job)', multiplier: 1.9 }
  };

  const calculateCalories = () => {
    const a = parseInt(age);
    const w = parseFloat(weight);
    const h = parseFloat(height);

    if (a && w && h) {
      let bmr;
      
      // Harris-Benedict Equation
      if (gender === 'male') {
        bmr = 88.362 + (13.397 * w) + (4.799 * h) - (5.677 * a);
      } else {
        bmr = 447.593 + (9.247 * w) + (3.098 * h) - (4.330 * a);
      }

      const tdee = bmr * activityLevels[activity].multiplier;

      setResults({
        bmr: Math.round(bmr),
        maintenance: Math.round(tdee),
        weightLoss: Math.round(tdee - 500),
        weightGain: Math.round(tdee + 500)
      });
    }
  };

  const reset = () => {
    setAge('');
    setWeight('');
    setHeight('');
    setGender('male');
    setActivity('sedentary');
    setResults(null);
  };

  return (
    <div className="calculator-container fade-in">
      <div className="calculator-header">
        <h2>Calorie Calculator</h2>
        <p>Calculate your daily caloric needs</p>
      </div>
      
      <div className="calculator-body">
        <div className="form-group">
          <label>Gender</label>
          <div style={{ display: 'flex', gap: '1rem', marginTop: '0.5rem' }}>
            <label style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', cursor: 'pointer' }}>
              <input
                type="radio"
                name="gender"
                value="male"
                checked={gender === 'male'}
                onChange={(e) => setGender(e.target.value)}
              />
              Male
            </label>
            <label style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', cursor: 'pointer' }}>
              <input
                type="radio"
                name="gender"
                value="female"
                checked={gender === 'female'}
                onChange={(e) => setGender(e.target.value)}
              />
              Female
            </label>
          </div>
        </div>

        <div className="form-group">
          <label htmlFor="age">Age (years)</label>
          <input
            id="age"
            type="number"
            className="form-input"
            value={age}
            onChange={(e) => setAge(e.target.value)}
            placeholder="e.g., 30"
          />
        </div>

        <div className="form-group">
          <label htmlFor="weight">Weight (kg)</label>
          <input
            id="weight"
            type="number"
            step="0.1"
            className="form-input"
            value={weight}
            onChange={(e) => setWeight(e.target.value)}
            placeholder="e.g., 70"
          />
        </div>

        <div className="form-group">
          <label htmlFor="height">Height (cm)</label>
          <input
            id="height"
            type="number"
            className="form-input"
            value={height}
            onChange={(e) => setHeight(e.target.value)}
            placeholder="e.g., 175"
          />
        </div>

        <div className="form-group">
          <label htmlFor="activity">Activity Level</label>
          <select 
            id="activity"
            className="form-select"
            value={activity}
            onChange={(e) => setActivity(e.target.value)}
          >
            {Object.entries(activityLevels).map(([key, value]) => (
              <option key={key} value={key}>{value.label}</option>
            ))}
          </select>
        </div>

        <div className="form-buttons">
          <button className="btn btn-primary" onClick={calculateCalories}>
            Calculate
          </button>
          <button className="btn btn-secondary" onClick={reset}>
            Reset
          </button>
        </div>

        {results && (
          <div className="results-container slide-in">
            <h3 style={{ marginBottom: '1.5rem', color: '#0369a1' }}>Your Daily Calorie Needs</h3>
            
            <div style={{ 
              textAlign: 'center', 
              padding: '2rem', 
              backgroundColor: 'rgba(59, 130, 246, 0.1)',
              borderRadius: '15px',
              marginBottom: '2rem'
            }}>
              <div style={{ fontSize: '2.5rem', fontWeight: '700', color: '#1d4ed8', marginBottom: '0.5rem' }}>
                {results.maintenance} cal/day
              </div>
              <div style={{ color: '#64748b' }}>Maintenance Calories</div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1rem', marginBottom: '2rem' }}>
              <div style={{ 
                textAlign: 'center', 
                padding: '1.5rem', 
                backgroundColor: 'rgba(239, 68, 68, 0.1)',
                borderRadius: '10px'
              }}>
                <div style={{ fontSize: '1.5rem', fontWeight: '600', color: '#dc2626' }}>
                  {results.weightLoss}
                </div>
                <div style={{ fontSize: '0.9rem', color: '#64748b' }}>Weight Loss</div>
                <div style={{ fontSize: '0.75rem', color: '#94a3b8' }}>(-1 lb/week)</div>
              </div>

              <div style={{ 
                textAlign: 'center', 
                padding: '1.5rem', 
                backgroundColor: 'rgba(16, 185, 129, 0.1)',
                borderRadius: '10px'
              }}>
                <div style={{ fontSize: '1.5rem', fontWeight: '600', color: '#059669' }}>
                  {results.maintenance}
                </div>
                <div style={{ fontSize: '0.9rem', color: '#64748b' }}>Maintain Weight</div>
                <div style={{ fontSize: '0.75rem', color: '#94a3b8' }}>Current weight</div>
              </div>

              <div style={{ 
                textAlign: 'center', 
                padding: '1.5rem', 
                backgroundColor: 'rgba(59, 130, 246, 0.1)',
                borderRadius: '10px'
              }}>
                <div style={{ fontSize: '1.5rem', fontWeight: '600', color: '#2563eb' }}>
                  {results.weightGain}
                </div>
                <div style={{ fontSize: '0.9rem', color: '#64748b' }}>Weight Gain</div>
                <div style={{ fontSize: '0.75rem', color: '#94a3b8' }}>(+1 lb/week)</div>
              </div>
            </div>

            <div className="result-item">
              <span className="result-label">Basal Metabolic Rate (BMR):</span>
              <span className="result-value">{results.bmr} cal/day</span>
            </div>

            <div style={{ marginTop: '2rem', padding: '1rem', backgroundColor: 'rgba(245, 158, 11, 0.1)', borderRadius: '10px', fontSize: '0.85rem', color: '#92400e' }}>
              <strong>Note:</strong> These calculations are estimates based on the Harris-Benedict equation. Individual metabolic rates can vary. For personalized nutrition advice, consult with a healthcare professional or registered dietitian.
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default CalorieCalculator;