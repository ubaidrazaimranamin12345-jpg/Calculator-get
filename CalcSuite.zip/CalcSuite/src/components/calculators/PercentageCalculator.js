import React, { useState } from 'react';

const PercentageCalculator = () => {
  const [activeTab, setActiveTab] = useState('what-is');
  const [result, setResult] = useState('');

  // Tab 1: What is X% of Y?
  const [percentage1, setPercentage1] = useState('');
  const [number1, setNumber1] = useState('');

  // Tab 2: X is what % of Y?
  const [number2, setNumber2] = useState('');
  const [total2, setTotal2] = useState('');

  // Tab 3: Percentage Change
  const [originalValue, setOriginalValue] = useState('');
  const [newValue, setNewValue] = useState('');

  const calculateWhatIs = () => {
    const percent = parseFloat(percentage1);
    const number = parseFloat(number1);
    if (!isNaN(percent) && !isNaN(number)) {
      const result = (percent / 100) * number;
      setResult(`${percent}% of ${number} is ${result}`);
    }
  };

  const calculateWhatPercent = () => {
    const num = parseFloat(number2);
    const total = parseFloat(total2);
    if (!isNaN(num) && !isNaN(total) && total !== 0) {
      const result = (num / total) * 100;
      setResult(`${num} is ${result.toFixed(2)}% of ${total}`);
    }
  };

  const calculatePercentageChange = () => {
    const original = parseFloat(originalValue);
    const newVal = parseFloat(newValue);
    if (!isNaN(original) && !isNaN(newVal) && original !== 0) {
      const change = ((newVal - original) / original) * 100;
      const changeType = change >= 0 ? 'increase' : 'decrease';
      setResult(`${Math.abs(change).toFixed(2)}% ${changeType} from ${original} to ${newVal}`);
    }
  };

  const reset = () => {
    setPercentage1('');
    setNumber1('');
    setNumber2('');
    setTotal2('');
    setOriginalValue('');
    setNewValue('');
    setResult('');
  };

  const tabs = [
    { id: 'what-is', label: 'What is X% of Y?' },
    { id: 'what-percent', label: 'X is what % of Y?' },
    { id: 'percentage-change', label: 'Percentage Change' }
  ];

  return (
    <div className="calculator-container fade-in">
      <div className="calculator-header">
        <h2>Percentage Calculator</h2>
        <p>Calculate percentages, increases, and decreases</p>
      </div>
      
      <div className="calculator-body">
        {/* Tabs */}
        <div style={{ 
          display: 'flex', 
          borderBottom: '2px solid #e2e8f0', 
          marginBottom: '2rem',
          overflow: 'auto'
        }}>
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => {setActiveTab(tab.id); setResult('');}}
              style={{
                padding: '1rem 1.5rem',
                border: 'none',
                background: activeTab === tab.id ? '#667eea' : 'transparent',
                color: activeTab === tab.id ? 'white' : '#64748b',
                fontWeight: '600',
                borderRadius: '8px 8px 0 0',
                cursor: 'pointer',
                transition: 'all 0.3s ease',
                whiteSpace: 'nowrap',
                fontSize: '0.9rem'
              }}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        {activeTab === 'what-is' && (
          <div>
            <h3 style={{ marginBottom: '1.5rem', color: '#374151' }}>What is X% of Y?</h3>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
              <div className="form-group">
                <label>Percentage (%)</label>
                <input
                  type="number"
                  className="form-input"
                  value={percentage1}
                  onChange={(e) => setPercentage1(e.target.value)}
                  placeholder="e.g., 15"
                />
              </div>
              <div className="form-group">
                <label>Number</label>
                <input
                  type="number"
                  className="form-input"
                  value={number1}
                  onChange={(e) => setNumber1(e.target.value)}
                  placeholder="e.g., 200"
                />
              </div>
            </div>
            <button className="btn btn-primary" onClick={calculateWhatIs} style={{ width: '100%' }}>
              Calculate
            </button>
          </div>
        )}

        {activeTab === 'what-percent' && (
          <div>
            <h3 style={{ marginBottom: '1.5rem', color: '#374151' }}>X is what % of Y?</h3>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
              <div className="form-group">
                <label>Number (X)</label>
                <input
                  type="number"
                  className="form-input"
                  value={number2}
                  onChange={(e) => setNumber2(e.target.value)}
                  placeholder="e.g., 25"
                />
              </div>
              <div className="form-group">
                <label>Total (Y)</label>
                <input
                  type="number"
                  className="form-input"
                  value={total2}
                  onChange={(e) => setTotal2(e.target.value)}
                  placeholder="e.g., 100"
                />
              </div>
            </div>
            <button className="btn btn-primary" onClick={calculateWhatPercent} style={{ width: '100%' }}>
              Calculate
            </button>
          </div>
        )}

        {activeTab === 'percentage-change' && (
          <div>
            <h3 style={{ marginBottom: '1.5rem', color: '#374151' }}>Percentage Change</h3>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
              <div className="form-group">
                <label>Original Value</label>
                <input
                  type="number"
                  className="form-input"
                  value={originalValue}
                  onChange={(e) => setOriginalValue(e.target.value)}
                  placeholder="e.g., 50"
                />
              </div>
              <div className="form-group">
                <label>New Value</label>
                <input
                  type="number"
                  className="form-input"
                  value={newValue}
                  onChange={(e) => setNewValue(e.target.value)}
                  placeholder="e.g., 75"
                />
              </div>
            </div>
            <button className="btn btn-primary" onClick={calculatePercentageChange} style={{ width: '100%' }}>
              Calculate Change
            </button>
          </div>
        )}

        <div className="form-buttons" style={{ marginTop: '2rem' }}>
          <button className="btn btn-secondary" onClick={reset}>
            Reset All
          </button>
        </div>

        {result && (
          <div className="results-container slide-in">
            <div style={{ 
              textAlign: 'center', 
              padding: '2rem', 
              backgroundColor: 'rgba(102, 126, 234, 0.1)',
              borderRadius: '15px',
              border: '2px solid rgba(102, 126, 234, 0.3)'
            }}>
              <div style={{ fontSize: '1.5rem', fontWeight: '600', color: '#4c51bf' }}>
                {result}
              </div>
            </div>
          </div>
        )}

        {/* Formula Reference */}
        <div style={{ marginTop: '2rem', padding: '1rem', backgroundColor: 'rgba(148, 163, 184, 0.1)', borderRadius: '10px', fontSize: '0.85rem', color: '#475569' }}>
          <h4 style={{ marginBottom: '1rem', color: '#334155' }}>Formula Reference:</h4>
          <div style={{ display: 'grid', gap: '0.5rem' }}>
            <div><strong>What is X% of Y:</strong> (X ÷ 100) × Y</div>
            <div><strong>X is what % of Y:</strong> (X ÷ Y) × 100</div>
            <div><strong>Percentage Change:</strong> ((New - Original) ÷ Original) × 100</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PercentageCalculator;