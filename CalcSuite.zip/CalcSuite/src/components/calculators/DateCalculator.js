import React, { useState } from 'react';

const DateCalculator = () => {
  const [activeTab, setActiveTab] = useState('add-subtract');

  // Add/Subtract tab
  const [startDate, setStartDate] = useState('');
  const [days, setDays] = useState('');
  const [operation, setOperation] = useState('add');
  const [resultDate, setResultDate] = useState('');

  // Date difference tab
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');
  const [difference, setDifference] = useState(null);

  const calculateAddSubtract = () => {
    if (startDate && days) {
      const date = new Date(startDate);
      const daysNum = parseInt(days);
      
      if (operation === 'add') {
        date.setDate(date.getDate() + daysNum);
      } else {
        date.setDate(date.getDate() - daysNum);
      }
      
      setResultDate(date.toISOString().split('T')[0]);
    }
  };

  const calculateDifference = () => {
    if (fromDate && toDate) {
      const from = new Date(fromDate);
      const to = new Date(toDate);
      
      if (from > to) {
        alert('From date cannot be after To date');
        return;
      }

      // Calculate exact difference
      let years = to.getFullYear() - from.getFullYear();
      let months = to.getMonth() - from.getMonth();
      let days = to.getDate() - from.getDate();

      if (days < 0) {
        months--;
        const daysInPrevMonth = new Date(to.getFullYear(), to.getMonth(), 0).getDate();
        days += daysInPrevMonth;
      }

      if (months < 0) {
        years--;
        months += 12;
      }

      // Calculate total time units
      const totalDays = Math.floor((to - from) / (1000 * 60 * 60 * 24));
      const totalHours = totalDays * 24;
      const totalWeeks = Math.floor(totalDays / 7);

      setDifference({
        years,
        months,
        days,
        totalDays,
        totalWeeks,
        totalHours: totalHours.toLocaleString()
      });
    }
  };

  const useToday = (setter) => {
    setter(new Date().toISOString().split('T')[0]);
  };

  const reset = () => {
    // Add/Subtract tab
    setStartDate('');
    setDays('');
    setOperation('add');
    setResultDate('');
    
    // Difference tab
    setFromDate('');
    setToDate('');
    setDifference(null);
  };

  const tabs = [
    { id: 'add-subtract', label: 'Add/Subtract Days' },
    { id: 'difference', label: 'Date Difference' }
  ];

  return (
    <div className="calculator-container fade-in">
      <div className="calculator-header">
        <h2>Date Calculator</h2>
        <p>Add/subtract days and calculate date differences</p>
      </div>
      
      <div className="calculator-body">
        {/* Tabs */}
        <div style={{ 
          display: 'flex', 
          borderBottom: '2px solid #e2e8f0', 
          marginBottom: '2rem',
          overflow: 'auto'
        }}>
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => {setActiveTab(tab.id); reset();}}
              style={{
                padding: '1rem 2rem',
                border: 'none',
                background: activeTab === tab.id ? '#667eea' : 'transparent',
                color: activeTab === tab.id ? 'white' : '#64748b',
                fontWeight: '600',
                borderRadius: '8px 8px 0 0',
                cursor: 'pointer',
                transition: 'all 0.3s ease',
                whiteSpace: 'nowrap'
              }}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        {activeTab === 'add-subtract' && (
          <div>
            <h3 style={{ marginBottom: '1.5rem', color: '#374151' }}>Add or Subtract Days</h3>
            
            <div className="form-group">
              <label htmlFor="startDate">Starting Date</label>
              <div style={{ display: 'flex', gap: '0.5rem' }}>
                <input
                  id="startDate"
                  type="date"
                  className="form-input"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  style={{ flex: 1 }}
                />
                <button 
                  type="button"
                  onClick={() => useToday(setStartDate)}
                  style={{
                    padding: '0.5rem 1rem',
                    background: '#f1f5f9',
                    border: '2px solid #e2e8f0',
                    borderRadius: '10px',
                    cursor: 'pointer',
                    fontSize: '0.9rem',
                    whiteSpace: 'nowrap'
                  }}
                >
                  Use Today
                </button>
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '1rem' }}>
              <div className="form-group">
                <label htmlFor="days">Number of Days</label>
                <input
                  id="days"
                  type="number"
                  className="form-input"
                  value={days}
                  onChange={(e) => setDays(e.target.value)}
                  placeholder="e.g., 30"
                />
              </div>

              <div className="form-group">
                <label htmlFor="operation">Operation</label>
                <select 
                  id="operation"
                  className="form-select"
                  value={operation}
                  onChange={(e) => setOperation(e.target.value)}
                >
                  <option value="add">Add Days</option>
                  <option value="subtract">Subtract Days</option>
                </select>
              </div>
            </div>

            <button className="btn btn-primary" onClick={calculateAddSubtract} style={{ width: '100%' }}>
              Calculate Date
            </button>

            {resultDate && (
              <div className="results-container slide-in">
                <div style={{ 
                  textAlign: 'center', 
                  padding: '2rem', 
                  backgroundColor: 'rgba(16, 185, 129, 0.1)',
                  borderRadius: '15px'
                }}>
                  <div style={{ fontSize: '0.9rem', color: '#64748b', marginBottom: '0.5rem' }}>
                    {operation === 'add' ? 'Adding' : 'Subtracting'} {days} days {operation === 'add' ? 'to' : 'from'} {startDate}
                  </div>
                  <div style={{ fontSize: '2rem', fontWeight: '700', color: '#059669' }}>
                    {new Date(resultDate).toLocaleDateString('en-US', { 
                      weekday: 'long', 
                      year: 'numeric', 
                      month: 'long', 
                      day: 'numeric' 
                    })}
                  </div>
                  <div style={{ fontSize: '1.2rem', color: '#6b7280', marginTop: '0.5rem' }}>
                    {resultDate}
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {activeTab === 'difference' && (
          <div>
            <h3 style={{ marginBottom: '1.5rem', color: '#374151' }}>Calculate Date Difference</h3>
            
            <div className="form-group">
              <label htmlFor="fromDate">From Date</label>
              <div style={{ display: 'flex', gap: '0.5rem' }}>
                <input
                  id="fromDate"
                  type="date"
                  className="form-input"
                  value={fromDate}
                  onChange={(e) => setFromDate(e.target.value)}
                  style={{ flex: 1 }}
                />
                <button 
                  type="button"
                  onClick={() => useToday(setFromDate)}
                  style={{
                    padding: '0.5rem 1rem',
                    background: '#f1f5f9',
                    border: '2px solid #e2e8f0',
                    borderRadius: '10px',
                    cursor: 'pointer',
                    fontSize: '0.9rem',
                    whiteSpace: 'nowrap'
                  }}
                >
                  Today
                </button>
              </div>
            </div>

            <div className="form-group">
              <label htmlFor="toDate">To Date</label>
              <div style={{ display: 'flex', gap: '0.5rem' }}>
                <input
                  id="toDate"
                  type="date"
                  className="form-input"
                  value={toDate}
                  onChange={(e) => setToDate(e.target.value)}
                  style={{ flex: 1 }}
                />
                <button 
                  type="button"
                  onClick={() => useToday(setToDate)}
                  style={{
                    padding: '0.5rem 1rem',
                    background: '#f1f5f9',
                    border: '2px solid #e2e8f0',
                    borderRadius: '10px',
                    cursor: 'pointer',
                    fontSize: '0.9rem',
                    whiteSpace: 'nowrap'
                  }}
                >
                  Today
                </button>
              </div>
            </div>

            <button className="btn btn-primary" onClick={calculateDifference} style={{ width: '100%' }}>
              Calculate Difference
            </button>

            {difference && (
              <div className="results-container slide-in">
                <div style={{ 
                  textAlign: 'center', 
                  padding: '2rem', 
                  backgroundColor: 'rgba(59, 130, 246, 0.1)',
                  borderRadius: '15px',
                  marginBottom: '2rem'
                }}>
                  <div style={{ fontSize: '2rem', fontWeight: '700', color: '#2563eb', marginBottom: '0.5rem' }}>
                    {difference.years} years, {difference.months} months, {difference.days} days
                  </div>
                  <div style={{ color: '#64748b' }}>Exact Difference</div>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))', gap: '1rem' }}>
                  <div style={{ 
                    textAlign: 'center', 
                    padding: '1.5rem', 
                    backgroundColor: 'rgba(16, 185, 129, 0.1)',
                    borderRadius: '10px'
                  }}>
                    <div style={{ fontSize: '1.8rem', fontWeight: '700', color: '#059669' }}>
                      {difference.totalDays.toLocaleString()}
                    </div>
                    <div style={{ color: '#64748b' }}>Total Days</div>
                  </div>

                  <div style={{ 
                    textAlign: 'center', 
                    padding: '1.5rem', 
                    backgroundColor: 'rgba(245, 158, 11, 0.1)',
                    borderRadius: '10px'
                  }}>
                    <div style={{ fontSize: '1.8rem', fontWeight: '700', color: '#d97706' }}>
                      {difference.totalWeeks.toLocaleString()}
                    </div>
                    <div style={{ color: '#64748b' }}>Total Weeks</div>
                  </div>

                  <div style={{ 
                    textAlign: 'center', 
                    padding: '1.5rem', 
                    backgroundColor: 'rgba(139, 92, 246, 0.1)',
                    borderRadius: '10px'
                  }}>
                    <div style={{ fontSize: '1.5rem', fontWeight: '700', color: '#7c3aed' }}>
                      {difference.totalHours}
                    </div>
                    <div style={{ color: '#64748b' }}>Total Hours</div>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        <div className="form-buttons" style={{ marginTop: '2rem' }}>
          <button className="btn btn-secondary" onClick={reset}>
            Reset
          </button>
        </div>
      </div>
    </div>
  );
};

export default DateCalculator;