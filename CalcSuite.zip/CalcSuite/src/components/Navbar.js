import React from 'react';
import { Link } from 'react-router-dom';

const Navbar = ({ darkMode, setDarkMode }) => {
  return (
    <nav className="nav">
      <div className="container nav-container">
        <Link to="/" className="nav-brand">
          🧮 CalcPro
        </Link>
        
        <ul className="nav-links">
          <li><Link to="/">Home</Link></li>
          <li><Link to="/calculator/basic">Basic</Link></li>
          <li><Link to="/calculator/scientific">Scientific</Link></li>
          <li><Link to="/calculator/mortgage">Financial</Link></li>
          <li><Link to="/calculator/bmi">Health</Link></li>
        </ul>
        
        <button 
          className="dark-toggle"
          onClick={() => setDarkMode(!darkMode)}
        >
          {darkMode ? '☀️' : '🌙'}
        </button>
      </div>
    </nav>
  );
};

export default Navbar;