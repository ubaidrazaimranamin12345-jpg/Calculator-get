import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import './App.css';

// Components
import Navbar from './components/Navbar';
import Home from './pages/Home';
import BasicCalculator from './components/calculators/BasicCalculator';
import ScientificCalculator from './components/calculators/ScientificCalculator';
import MortgageCalculator from './components/calculators/MortgageCalculator';
import LoanCalculator from './components/calculators/LoanCalculator';
import BMICalculator from './components/calculators/BMICalculator';
import CalorieCalculator from './components/calculators/CalorieCalculator';
import PercentageCalculator from './components/calculators/PercentageCalculator';
import AgeCalculator from './components/calculators/AgeCalculator';
import DateCalculator from './components/calculators/DateCalculator';

function App() {
  const [darkMode, setDarkMode] = useState(false);

  return (
    <div className={`App ${darkMode ? 'dark' : ''}`}>
      <Router>
        <Navbar darkMode={darkMode} setDarkMode={setDarkMode} />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/calculator/basic" element={<BasicCalculator />} />
          <Route path="/calculator/scientific" element={<ScientificCalculator />} />
          <Route path="/calculator/mortgage" element={<MortgageCalculator />} />
          <Route path="/calculator/loan" element={<LoanCalculator />} />
          <Route path="/calculator/bmi" element={<BMICalculator />} />
          <Route path="/calculator/calorie" element={<CalorieCalculator />} />
          <Route path="/calculator/percentage" element={<PercentageCalculator />} />
          <Route path="/calculator/age" element={<AgeCalculator />} />
          <Route path="/calculator/date" element={<DateCalculator />} />
        </Routes>
      </Router>
    </div>
  );
}

export default App;