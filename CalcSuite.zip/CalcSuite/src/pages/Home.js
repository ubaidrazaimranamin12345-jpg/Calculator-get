import React, { useState } from 'react';
import { Link } from 'react-router-dom';

const Home = () => {
  const [searchTerm, setSearchTerm] = useState('');

  const calculators = [
    {
      id: 'basic',
      title: 'Basic Calculator',
      description: 'Standard arithmetic operations with memory functions',
      icon: '🧮',
      category: 'math',
      path: '/calculator/basic'
    },
    {
      id: 'scientific',
      title: 'Scientific Calculator',
      description: 'Advanced mathematical functions and trigonometry',
      icon: '🔬',
      category: 'math',
      path: '/calculator/scientific'
    },
    {
      id: 'mortgage',
      title: 'Mortgage Calculator',
      description: 'Calculate monthly payments and total interest',
      icon: '🏠',
      category: 'financial',
      path: '/calculator/mortgage'
    },
    {
      id: 'loan',
      title: 'Loan Calculator',
      description: 'Personal and business loan calculations',
      icon: '💰',
      category: 'financial',
      path: '/calculator/loan'
    },
    {
      id: 'bmi',
      title: 'BMI Calculator',
      description: 'Body Mass Index calculator with health categories',
      icon: '⚖️',
      category: 'health',
      path: '/calculator/bmi'
    },
    {
      id: 'calorie',
      title: 'Calorie Calculator',
      description: 'Daily caloric needs based on activity level',
      icon: '🔥',
      category: 'health',
      path: '/calculator/calorie'
    },
    {
      id: 'percentage',
      title: 'Percentage Calculator',
      description: 'Calculate percentages, increases, and decreases',
      icon: '📊',
      category: 'math',
      path: '/calculator/percentage'
    },
    {
      id: 'age',
      title: 'Age Calculator',
      description: 'Calculate exact age in years, months, and days',
      icon: '📅',
      category: 'tools',
      path: '/calculator/age'
    },
    {
      id: 'date',
      title: 'Date Calculator',
      description: 'Add/subtract days and calculate date differences',
      icon: '📆',
      category: 'tools',
      path: '/calculator/date'
    }
  ];

  const filteredCalculators = calculators.filter(calc =>
    calc.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    calc.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="fade-in">
      {/* Hero Section */}
      <header className="header">
        <div className="container">
          <h1>Professional Calculator Suite</h1>
          <p>
            Powerful, accurate calculators for finance, health, math, and everyday calculations
          </p>
        </div>
      </header>

      <div className="container">
        {/* Search Bar */}
        <div className="search-container">
          <div style={{ position: 'relative' }}>
            <span className="search-icon">🔍</span>
            <input
              type="text"
              className="search-input"
              placeholder="Search for a calculator..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>

        {/* Calculator Categories */}
        <section>
          <div className="calculator-grid">
            {filteredCalculators.map((calc) => (
              <Link key={calc.id} to={calc.path} className="calculator-card">
                <div className={`calculator-icon ${calc.category}`}>
                  <span>{calc.icon}</span>
                </div>
                <h3>{calc.title}</h3>
                <p>{calc.description}</p>
              </Link>
            ))}
          </div>
        </section>

        {filteredCalculators.length === 0 && (
          <div style={{ textAlign: 'center', padding: '4rem' }}>
            <h3>No calculators found</h3>
            <p>Try adjusting your search terms</p>
          </div>
        )}

        {/* Features Section */}
        <section style={{ padding: '4rem 0', textAlign: 'center' }}>
          <h2 style={{ marginBottom: '3rem', fontSize: '2.5rem' }}>Why Choose CalcPro?</h2>
          <div className="calculator-grid">
            <div className="calculator-card">
              <div className="calculator-icon math">
                <span>⚡</span>
              </div>
              <h3>Lightning Fast</h3>
              <p>Instant calculations with optimized algorithms for maximum performance</p>
            </div>
            <div className="calculator-card">
              <div className="calculator-icon health">
                <span>🎯</span>
              </div>
              <h3>Highly Accurate</h3>
              <p>Precision calculations using advanced mathematical libraries</p>
            </div>
            <div className="calculator-card">
              <div className="calculator-icon financial">
                <span>📱</span>
              </div>
              <h3>Mobile Friendly</h3>
              <p>Responsive design works perfectly on all devices and screen sizes</p>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};

export default Home;