# CalcPro - Modern Calculator Web Application

A comprehensive calculator web application similar to Calculator.net with modern design and enhanced user experience.

## Features

### 🧮 Calculator Types
- **Basic Calculator**: Standard arithmetic operations with modern UI
- **Scientific Calculator**: Advanced mathematical functions, trigonometry, logarithms
- **Financial Calculators**: 
  - Mortgage Calculator
  - Loan Calculator
  - Investment Calculator (coming soon)
- **Health & Fitness Calculators**:
  - BMI Calculator with categories
  - Calorie Calculator with activity levels
- **Math Tools**:
  - Percentage Calculator (multiple calculation types)
  - Random Number Generator (coming soon)
- **Utility Tools**:
  - Age Calculator with detailed breakdown
  - Date Calculator (add/subtract days, date difference)

### 🎨 Design Features
- Modern, responsive design
- Dark/light theme support ready
- Intuitive navigation
- Search functionality
- Category-based organization
- Mobile-first approach

### 💾 Data Features
- Calculation history saving
- In-memory storage (development)
- PostgreSQL support ready for production

## Technology Stack

### Frontend
- **React 18** with TypeScript
- **Vite** for build tooling
- **Tailwind CSS** for styling
- **shadcn/ui** component library
- **Wouter** for routing
- **TanStack React Query** for state management

### Backend
- **Node.js** with Express
- **TypeScript** with ES modules
- **Drizzle ORM** with PostgreSQL
- **Zod** for validation

### Development Tools
- Hot module replacement
- TypeScript strict mode
- ESLint configuration
- Automatic workflow management

## Getting Started

### Prerequisites
- Node.js 18+ 
- npm or yarn

### Installation

1. Clone the repository
```bash
git clone <repository-url>
cd calcpro
```

2. Install dependencies
```bash
npm install
```

3. Start development server
```bash
npm run dev
```

The application will be available at `http://localhost:5000`

## Project Structure

```
├── client/                 # Frontend React application
│   ├── src/
│   │   ├── components/     # Reusable UI components
│   │   │   ├── basic-calculator.tsx
│   │   │   ├── search-bar.tsx
│   │   │   ├── calculator-grid.tsx
│   │   │   ├── financial/  # Financial calculator components
│   │   │   ├── health/     # Health calculator components
│   │   │   ├── math/       # Math calculator components
│   │   │   └── tools/      # Utility calculator components
│   │   ├── pages/          # Page components
│   │   ├── lib/            # Utility functions and calculations
│   │   └── hooks/          # Custom React hooks
│   └── index.html
├── server/                 # Backend Express application
│   ├── index.ts           # Server entry point
│   ├── routes.ts          # API routes
│   ├── storage.ts         # Storage interface and implementation
│   └── vite.ts            # Vite integration
├── shared/                # Shared types and schemas
│   └── schema.ts          # Database schema and types
└── package.json
```

## Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run preview` - Preview production build
- `npm run type-check` - Run TypeScript type checking

## API Endpoints

### Calculations
- `GET /api/calculations` - Get all calculations
- `GET /api/calculations/:type` - Get calculations by type
- `POST /api/calculations` - Create new calculation
- `DELETE /api/calculations/:id` - Delete calculation

## Calculator Types Reference

### Basic Calculator
Standard arithmetic operations with memory functions and percentage calculations.

### Scientific Calculator
- Trigonometric functions (sin, cos, tan, inverse functions)
- Logarithmic functions (ln, log)
- Exponential functions (e^x, 10^x)
- Power functions (x², x³, x^y)
- Square root and cube root
- Constants (π, e)
- Factorial
- Degree/Radian mode toggle

### Financial Calculators

#### Mortgage Calculator
- Loan amount, interest rate, loan term
- Monthly payment calculation
- Total payment and interest breakdown
- Amortization summary

#### Loan Calculator
- Principal, interest rate, term in months
- Payment calculations for personal/business loans
- Total cost analysis

### Health Calculators

#### BMI Calculator
- Metric and Imperial unit support
- BMI category classification
- Health range indicators

#### Calorie Calculator
- BMR calculation using Harris-Benedict equation
- Activity level multipliers
- Daily calorie needs for weight goals

### Math Tools

#### Percentage Calculator
- What is X% of Y?
- X is what % of Y?
- Percentage increase/decrease calculations

### Utility Tools

#### Age Calculator
- Exact age calculation in years, months, days
- Total days, hours, minutes lived
- Flexible target date selection

#### Date Calculator
- Add/subtract days from dates
- Calculate difference between dates
- Multiple format support

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

MIT License - see LICENSE file for details

## Support

For support and questions, please open an issue on the repository.